
const nodemailer = require('nodemailer');
const fs = require('fs');

let BaseDatosFalsa = require("./BaseDatosFalsa");
let BaseDatosVerdadera = require("./BaseDatosVerdadera");

module.exports = async function(app){

    let clienteBD = new BaseDatosVerdadera(); // new BaseDatosFalsa(); 
	await clienteBD.conectarBaseDatos();
	let db = clienteBD.db;
	
	app.post("/pokemonapi/login", async function(request, response){
		let usuario = request.body.usuario;
		let contrasena = request.body.contrasena;
		
		let buscarUsuario = await db.Usuarios.find( { username: usuario, password: contrasena} ).toArray();

		if(buscarUsuario.length == 0){
			response.send( {} );
		}
		else{
			buscarUsuario = buscarUsuario[0];
			response.send(buscarUsuario);
		}
		
	});
	
	app.get("/pokemonapi/listarpokemones", async function(request, response){
		let pokemones = await db.Pokemones.find().toArray();
		response.send(pokemones);
	});
	
	
	app.post("/pokemonapi/actualizarpokemon", async function(request, response){
		let _id = request.body._id;
		let nombre = request.body.nombre;
		let tipo = request.body.tipo;
		let fuerza = request.body.fuerza;
		let velocidad = request.body.velocidad;
		let edad = request.body.edad;
		
		let urlImagen = "";
		
		// mover la imagen a una carpeta dentro de webroot y obtener la url de la imagen
		if(request.files.length > 0){
		
			let imagen = request.files[0];
		
			let extension = imagen.originalname.split(".")[1];
			let nuevoNombre = `${imagen.filename}.${extension}`;
			
			let viejaRuta = imagen.path;
			let nuevaRuta = "webroot/img/" + nuevoNombre;
			
			urlImagen = "/img/" + nuevoNombre; // actualiza la URL
			
			fs.rename(viejaRuta, nuevaRuta, () => { // mueve el archivo físico
				//console.log("\nFile Renamed!\n");
			});
		}
	
		let resultado = await clienteBD.actualizarPokemon(_id, nombre, tipo, fuerza, velocidad, edad, urlImagen);
		
		response.send(resultado);
	});
		
		
	app.post("/pokemonapi/insertarpokemon", async function(request, response){
	
		let nombre = request.body.nombre;
		let tipo = request.body.tipo;
		let fuerza = request.body.fuerza;
		let velocidad = request.body.velocidad;
		let edad = request.body.edad;
		
		let urlImagen = "";
		
		// mover la imagen a una carpeta dentro de webroot y obtener la url de la imagen
		if(request.files.length > 0){
		
			let imagen = request.files[0];
		
			let extension = imagen.originalname.split(".")[1];
			let nuevoNombre = `${imagen.filename}.${extension}`;
			
			let viejaRuta = imagen.path;
			let nuevaRuta = "webroot/img/" + nuevoNombre;
			
			urlImagen = "/img/" + nuevoNombre; // actualiza la URL
			
			fs.rename(viejaRuta, nuevaRuta, () => { // mueve el archivo físico
				//console.log("\nFile Renamed!\n");
			});
		}
	
		let resultado = await clienteBD.insertarPokemon(nombre, tipo, fuerza, velocidad, edad, urlImagen);
		
		response.send(resultado);
	});
	

	app.get("/pokemonapi/listarrivales", async function(request, response){
	
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		
		// filtrar rivales que me han invitado o yo he invitado, pero que no han finalizado
		let duelos = await db.Duelos.find( { estado: {$ne: "Fin"} } ).toArray(); // estado != "Fin"
		let misRivales = [];
		
		for(let duelo of duelos){
			if(duelo.usuarioRival == usuarioActual){
				let nuevoRival = {
					idDuelo: duelo._id,
					username: duelo.usuarioRetador,
					estado: duelo.estado,
					accion: "retador",
					miEquipo: duelo.equipoRival,
					equipoOponente: duelo.equipoRetador
				};
				misRivales.push(nuevoRival);
			}
			else if(duelo.usuarioRetador == usuarioActual){
				let nuevoRival = {
					idDuelo: duelo._id,
					username: duelo.usuarioRival,
					estado: duelo.estado,
					accion: "rival",
					miEquipo: duelo.equipoRetador,
					equipoOponente: duelo.equipoRival
				};
				misRivales.push(nuevoRival);
			}
		}
	
	    // filtrar posibles duelos (el resto de usuarios)
		let usuarios = await db.Usuarios.find( 
					{perfil: "entrenador", _id: {$ne: usuarioActual} } ).toArray(); // perfil == "entrenador" && _id != usuarioActual
		let misRetos = [];
		
		for(let usuario of usuarios){
		    let esRival = false;
			for(let rival of misRivales){
				if(usuario._id == rival.username){
					esRival = true;
					break;
				}
			}
			
			if(esRival == false){
				let nuevoReto = {
					idDuelo: null,
					username: usuario._id,
					estado: null,
					accion: "reto"
				};
			    misRetos.push(nuevoReto);
			}
		}
		
		let entrenadores = [];
		
		for(let rival of misRivales){
			entrenadores.push(rival);
		}
		
		for(let reto of misRetos){
			entrenadores.push(reto);
		}
		
		response.send(entrenadores);
	});

	
	app.post("/pokemonapi/insertarduelo", async function(request, response){
	
		let idRetador = request.body.idRetador;
		let idRival = request.body.idRival;
	
		let resultado = await clienteBD.insertarDuelo(idRetador, idRival);
		
		response.send(resultado);
	});

	app.post("/pokemonapi/actualizarduelo", async function(request, response){
		// recoger datos del cliente
		let idDuelo = request.body.idDuelo;
		let nuevoEstado = request.body.nuevoEstado;
		let idGanador = request.body.idGanador;
		let equipoRetador = request.body.equipoRetador;
		let equipoRival = request.body.equipoRival;
		
		let resultado = await clienteBD.actualizarDuelo(idDuelo, nuevoEstado, idGanador, equipoRetador, equipoRival);
		
		//console.log(`idGanador: ${idGanador}`);
		
		response.send(resultado);
	});
	
	app.get("/pokemonapi/listarpokemonesusuarioequipo", async function(request, response){
	
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		let equipo = request.query.equipo; // parámetro de la URL
		
		// resultado final
		let misPokemones = [];
		
		// filtrar ids de pokemones dado el id de usuario
		let pokemonesUsuario = 
			await db.PokemonesUsuarios.find( {idUsuario: usuarioActual, equipo: equipo} ).toArray();
			
		if(pokemonesUsuario.length > 0){
			// buscar cada pokemon dado su id y agregarlo al resultado
			for(pu of pokemonesUsuario){
				let pokemones = await db.Pokemones.find({_id: pu.idPokemon}).toArray();
				
				if(pokemones.length > 0){
					let pokemon = pokemones[0];
					pokemon.equipo = pu.equipo; // agregar el dato del equipo al resto de información
					pokemon.entrenador = pu.idUsuario; // también el entrenador ...
					misPokemones.push(pokemon);
				}
			}
		}
		
		response.send(misPokemones);
	});
	

	app.get("/pokemonapi/misequipos", async function(request, response){
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		
		// primero, filtrar mis pokemones
		let pokemonesUsuarios = await db.PokemonesUsuarios.find( { idUsuario: usuarioActual} ).toArray();
		
		let misEquipos = []; // Ejemplo: { equipo: "ash-1", pokemones: [ ... ] }
		
		// luego, rellenar mis equipos con los pokemones respectivos
		for(let pU of pokemonesUsuarios){
			let equipo = pU.equipo;
			let idPokemon = pU.idPokemon;
			
			// buscar la info del pokemon
			let infoPokemon = await db.Pokemones.find( {_id: idPokemon} ).toArray();
			infoPokemon = infoPokemon[0];
			
			// si no hemos agregado este equipo, agregarlo, si sí, agregarle el pokemon nada más
			let buscarEquipo = misEquipos.filter(e => e.equipo == equipo);
			if(buscarEquipo.length == 0){
				let nuevoEquipo = {
					equipo: equipo,
					pokemones: [infoPokemon]
				};
				misEquipos.push( nuevoEquipo );
			}
			else{
				let equipoExistente = buscarEquipo[0];
				equipoExistente.pokemones.push(infoPokemon);
			}
		}
		
		response.send(misEquipos);
	});
	
	
	app.post("/pokemonapi/insertarpokemonusuario", async function(request, response){
	
		let idUsuario = request.body.idUsuario;
		let idPokemon = request.body.idPokemon;
		let equipo = request.body.equipo;
		
		let resultado = 
			await clienteBD.insertarPokemonUsuario(idUsuario, idPokemon, equipo);
			
		response.send( {message: "Registro agregado!!" } );
	});
	
	
	app.post("/pokemonapi/eliminarpokemonusuario", async function(request, response){
	
		let idUsuario = request.body.idUsuario;
		let idPokemon = request.body.idPokemon;
		let equipo = request.body.equipo;
		
		let resultado = 
			await clienteBD.eliminarPokemonUsuario(idUsuario, idPokemon, equipo);
			
		response.send( {message: "Registro agregado!!" } );
	});
	
	app.get("/pokemonapi/generarincognito", async function(request, response){
	
		var usernameAleatorio = "U-" + Math.floor(Math.random() * 1000);		
	
		let nuevoUsuario = await clienteBD.insertarUsuario(usernameAleatorio, null, "Incógnito", null); // sólo username (y _id) y perfil
		
		response.send(nuevoUsuario);
	});
	
	app.get("/pokemonapi/eliminarincognito", async function(request, response){
	
		var idUsuario = request.query.idUsuario;
		
		let respuesta = await clienteBD.eliminarUsuario(idUsuario);

		response.send({message: respuesta});
	});
	
	app.post("/pokemonapi/enviarcorreo", async function(request, response){
	
		let de = request.body.de;
		let para = request.body.para;
		let mensaje = request.body.mensaje;
		
		await mandarCorreo(de, para, mensaje);
		
		response.send("Correo enviado!");	
	});
	
	
	// REPORTES


	app.get("/pokemonapi/reportes/reportes2", async function(request, response){
			
		let usuarios = await db.Usuarios.find({}).toArray();
    
		let reportePerfiles = []; // Ejemplo: { usuario, , perfil, foto}
	
		for (let usuario of usuarios) {
			let perfil = {
				_id: usuario._id,
				perfil: usuario.perfil,
				foto: usuario.foto,
			};
	
			reportePerfiles.push(perfil);
			console.log();
		}
	
		
	
		response.send(reportePerfiles);
	});



	
	app.get("/pokemonapi/reportes/posiciones", async function(request, response){
	
		let duelos = await db.Duelos.find({estado: "Fin"}).toArray();
		
		let puntajesUsuarios = []; // Ejemplo: { idUsuario, duelosGanados, duelosPerdidos, puntaje }
		
		for(let d of duelos){
			let usuarioPerdedor = null;
			
			if(d.usuarioGanador == d.usuarioRetador){
				usuarioPerdedor = d.usuarioRival;
			}
			else{
				usuarioPerdedor = d.usuarioRetador;
			}

			let usuarioGana = puntajesUsuarios.filter(pU => pU.idUsuario == d.usuarioGanador);
			if(usuarioGana.length > 0){
				usuarioGana = usuarioGana[0];
				usuarioGana.duelosGanados++;
				usuarioGana.puntaje = usuarioGana.duelosGanados - usuarioGana.duelosPerdidos;
			}
			else{
				let nuevoPuntaje = {
					idUsuario: d.usuarioGanador, 
					duelosGanados: 1, duelosPerdidos: 0, puntaje: 1
				};
				puntajesUsuarios.push(nuevoPuntaje);
			}

			let usuarioPierde = puntajesUsuarios.filter(pU => pU.idUsuario == usuarioPerdedor);

			if(usuarioPierde.length > 0){
				usuarioPierde = usuarioPierde[0];
				usuarioPierde.duelosPerdidos++;
				usuarioPierde.puntaje = usuarioPierde.duelosGanados - usuarioPierde.duelosPerdidos;
			}
			else{
				let nuevoPuntaje = {
					idUsuario: usuarioPerdedor, 
					duelosGanados: 0, duelosPerdidos: 1, puntaje: -1
				};
				puntajesUsuarios.push(nuevoPuntaje);
			}
		}
		
		// ordenarlos por puntaje
		puntajesUsuarios = puntajesUsuarios.sort((a, b) => b.puntaje - a.puntaje);
		
		response.send(puntajesUsuarios);
	
	});
	
	app.get("/pokemonapi/reportes/ganes", async function(request, response){
	
		let idUsuario = request.query.idUsuario;
	
		let duelos = await db.Duelos.find({usuarioGanador: idUsuario}).toArray();
		
		let misPerdedores = []; // Ejemplo: { idUsuario, duelos }
		
		for(let d of duelos){
			let usuarioPerdedor = null;
			if(d.usuarioGanador == d.usuarioRetador){
				usuarioPerdedor = d.usuarioRival
			}
			else{
				usuarioPerdedor = d.usuarioRetador
			}

			let usuarioPierde = misPerdedores.filter(mP => mP.idUsuario == usuarioPerdedor);
			
			if(usuarioPierde.length > 0){
				usuarioPierde = usuarioPierde[0];
				usuarioPierde.duelos++;
			}
			else{
				misPerdedores.push( {idUsuario: usuarioPerdedor, duelos: 1} );
			}

		}
		
		// ordenarlos por duelos
		misPerdedores = misPerdedores.sort((a, b) => b.duelos - a.duelos);
		
		response.send(misPerdedores);
	
	});
	
	
	app.get("/pokemonapi/reportes/perdidas", async function(request, response){
	
		let idUsuario = request.query.idUsuario;
	
		let duelos = await db.Duelos.find().toArray();
		
		let misGanadores = []; // Ejemplo: { idUsuario, duelos }
		
		for(let d of duelos){
			let usuarioPerdedor = null;
			if(d.usuarioGanador == d.usuarioRetador){
				usuarioPerdedor = d.usuarioRival
			}
			else{
				usuarioPerdedor = d.usuarioRetador
			}
			
			if(usuarioPerdedor != idUsuario){
				continue; // continúa con el siguiente elemento del for
			}

			let usuarioGana = misGanadores.filter(mG => mG.idUsuario == d.usuarioGanador);
			
			if(usuarioGana.length > 0){
				usuarioGana = usuarioGana[0];
				usuarioGana.duelos++;
			}
			else{
				misGanadores.push( {idUsuario: d.usuarioGanador, duelos: 1} );
			}

		}
		
		// ordenarlos por duelos
		misGanadores = misGanadores.sort((a, b) => b.duelos - a.duelos);
		
		response.send(misGanadores);
	
	});
	
	
	app.get("/pokemonapi/reportes/ganesapokemones", async function(request, response){
	
		let idUsuario = request.query.idUsuario;
	
		let duelos = await db.Duelos.find({usuarioGanador: idUsuario}).toArray();
		let todosLosPokemones = await db.Pokemones.find().toArray(); // para obtener los nombres posteriormente
		
		let misPokemonesPerdedores = []; // Ejemplo: { idPokemon, nombre, duelos }
		
		for(let d of duelos){
			let quienPerdio = null;
			if(d.usuarioGanador == d.usuarioRetador){
				quienPerdio = "rival";
			}
			else{
				quienPerdio = "retador";
			}
			
			let detalleDuelo = await db.DetalleDuelos.find({idDuelo: d._id}).toArray();
			
			for(let dD of detalleDuelo){
			
				let pokemonPerdedor = null;
				if(quienPerdio == "rival"){
					pokemonPerdedor = dD.pokemonRival;
				}
				else{
					pokemonPerdedor = dD.pokemonRetador;
				}

				let pokemonPierde = misPokemonesPerdedores.filter(mP => mP.idPokemon == pokemonPerdedor);
				
				if(pokemonPierde.length > 0){
					pokemonPierde = pokemonPierde[0];
					pokemonPierde.duelos++;
				}
				else{
					misPokemonesPerdedores.push( {idPokemon: pokemonPerdedor, nombre: "", duelos: 1} );
				}
			}
		}
		
		// ordenarlos por duelos
		misPokemonesPerdedores = misPokemonesPerdedores.sort((a, b) => b.duelos - a.duelos);
		
		// agregar los nombres de los pokemones
		for(let mPP of misPokemonesPerdedores){
			let pokemon = todosLosPokemones.filter(p => p._id == mPP.idPokemon)[0];
			mPP.nombre = pokemon.nombre;
		}
		
		response.send(misPokemonesPerdedores);
	
	});
	
	
	app.get("/pokemonapi/reportes/perdidascontrapokemones", async function(request, response){
	
		let idUsuario = request.query.idUsuario;
	
		let duelos = await db.Duelos.find().toArray();
		let todosLosPokemones = await db.Pokemones.find().toArray(); // para obtener los nombres posteriormente
		
		let misPokemonesGanadores = []; // Ejemplo: { idPokemon, nombre, duelos }
		
		for(let d of duelos){
			let usuarioPerdedor = null;
			if(d.usuarioGanador == d.usuarioRetador){
				usuarioPerdedor = d.usuarioRival
			}
			else{
				usuarioPerdedor = d.usuarioRetador
			}
			
			if(usuarioPerdedor != idUsuario){
				continue; // continúa con el siguiente elemento del for
			}

			let quienGano = null;
			if(d.usuarioGanador == d.usuarioRetador){
				quienGano = "retador";
			}
			else{
				quienGano = "rival";
			}
			
			let detalleDuelo = await db.DetalleDuelos.find({idDuelo: d._id}).toArray();
			
			for(let dD of detalleDuelo){
			
				let pokemonGanador = null;
				if(quienGano == "rival"){
					pokemonGanador = dD.pokemonRival;
				}
				else{
					pokemonGanador = dD.pokemonRetador;
				}

				let pokemonGana = misPokemonesGanadores.filter(mP => mP.idPokemon == pokemonGanador);
				
				if(pokemonGana.length > 0){
					pokemonGana = pokemonGana[0];
					pokemonGana.duelos++;
				}
				else{
					misPokemonesGanadores.push( {idPokemon: pokemonGanador, nombre: "", duelos: 1} );
				}
			}
		}
		
		// ordenarlos por duelos
		misPokemonesGanadores = misPokemonesGanadores.sort((a, b) => b.duelos - a.duelos);
		
		// agregar los nombres de los pokemones
		for(let mPG of misPokemonesGanadores){
			let pokemon = todosLosPokemones.filter(p => p._id == mPG.idPokemon)[0];
			mPG.nombre = pokemon.nombre;
		}
		
		response.send(misPokemonesGanadores);
	
	});
}

async function mandarCorreo(de, para, mensaje){
	// Generate SMTP service account from ethereal.email
	nodemailer.createTestAccount((err, account) => {
	    if (err) {
	        console.error('Failed to create a testing account. ' + err.message);
	        return process.exit(1);
	    }

	    console.log('Credentials obtained, sending message...');

	    // Create a SMTP transporter object
	    const transporter = nodemailer.createTransport({
			host: 'smtp.ethereal.email',
			port: 587,
			auth: {
				user: 'alexander.spencer20@ethereal.email',
				pass: 'VTs5HUH3GmfsWeXfeY'
			}
		});

	    // Message object
	    let message = {
	        from: `Sender Name <${de}>`,
	        to: `Recipient <${para}>`,
	        subject: 'Proyecto de Ingeniería de Software 1',
	        text: mensaje,
	        html: `<h1>${mensaje}</h1>`
	    };

	    transporter.sendMail(message, (err, info) => {
	        if (err) {
	            console.log('Error occurred. ' + err.message);
	            return process.exit(1);
	        }

	        console.log('Message sent: %s', info.messageId);
	        // Preview only available when sending through an Ethereal account
	        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
	    });
	});
}












