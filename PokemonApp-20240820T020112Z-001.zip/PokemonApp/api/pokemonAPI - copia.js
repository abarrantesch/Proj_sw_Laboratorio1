
const nodemailer = require('nodemailer');
const fs = require('fs');

let baseDatosFalsa = require("./baseDatosFalsa");
let baseDatosVerdadera = require("./baseDatosVerdadera");

module.exports = async function(app){

    let clienteBD = new baseDatosVerdadera(); // new baseDatosFalsa(); 
	await clienteBD.conectarBaseDatos();
	//clienteBD.cargarDatosPrueba();
	let BaseDatos = clienteBD.BaseDatos;
	
	app.post("/pokemonapi/login", function(request, response){
		let usuario = request.body.usuario;
		let contrasena = request.body.contrasena;
		
		let buscarUsuario = BaseDatos.Usuarios.find(u => u.username == usuario && u.password == contrasena);
				
		if(buscarUsuario.length == 0){
			response.send( {} );
		}
		else{
			buscarUsuario = buscarUsuario[0];
			response.send(buscarUsuario);
		}
		
	});
	
	app.get("/pokemonapi/listarpokemones", function(request, response){
		let pokemones = BaseDatos.Pokemones;
		response.send(pokemones);
	});
	
	
	app.post("/pokemonapi/actualizarpokemon", function(request, response){
		let _id = request.body._id;
		let nombre = request.body.nombre;
		let tipo = request.body.tipo;
		let fuerza = request.body.fuerza;
		let velocidad = request.body.velocidad;
		let edad = request.body.edad;
		
		let urlImagen = "";
		
		// mover la imagen a una carpeta dentro de webroot y obtener la url de la imagen
		if(request.files.length > 0){
		
			let imagen = request.files[0];
		
			let extension = imagen.originalname.split(".")[1];
			let nuevoNombre = `${imagen.filename}.${extension}`;
			
			let viejaRuta = imagen.path;
			let nuevaRuta = "webroot/img/" + nuevoNombre;
			
			urlImagen = "/img/" + nuevoNombre; // actualiza la URL
			
			fs.rename(viejaRuta, nuevaRuta, () => { // mueve el archivo físico
				//console.log("\nFile Renamed!\n");
			});
		}
	
		let resultado = clienteBD.actualizarPokemon(_id, nombre, tipo, fuerza, velocidad, edad, urlImagen);
		
		response.send(resultado);
	});
		
		
	app.post("/pokemonapi/insertarpokemon", function(request, response){
	
		let nombre = request.body.nombre;
		let tipo = request.body.tipo;
		let fuerza = request.body.fuerza;
		let velocidad = request.body.velocidad;
		let edad = request.body.edad;
		
		let urlImagen = "";
		
		// mover la imagen a una carpeta dentro de webroot y obtener la url de la imagen
		if(request.files.length > 0){
		
			let imagen = request.files[0];
		
			let extension = imagen.originalname.split(".")[1];
			let nuevoNombre = `${imagen.filename}.${extension}`;
			
			let viejaRuta = imagen.path;
			let nuevaRuta = "webroot/img/" + nuevoNombre;
			
			urlImagen = "/img/" + nuevoNombre; // actualiza la URL
			
			fs.rename(viejaRuta, nuevaRuta, () => { // mueve el archivo físico
				//console.log("\nFile Renamed!\n");
			});
		}
	
		let resultado = clienteBD.insertarPokemon(nombre, tipo, fuerza, velocidad, edad, urlImagen);
		
		response.send(resultado);
	});
	

	app.get("/pokemonapi/listarrivales", function(request, response){
	
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		
		// filtrar rivales que me han invitado o yo he invitado, pero que no han finalizado
		let duelos = BaseDatos.Duelos.filter(u => u.estado != "Fin");
		let misRivales = [];
		
		for(let duelo of duelos){
			if(duelo.usuarioRival == usuarioActual){
				let nuevoRival = {
					idDuelo: duelo._id,
					username: duelo.usuarioRetador,
					estado: duelo.estado,
					accion: "retador",
					miEquipo: duelo.equipoRival,
					equipoOponente: duelo.equipoRetador
				};
				misRivales.push(nuevoRival);
			}
			else if(duelo.usuarioRetador == usuarioActual){
				let nuevoRival = {
					idDuelo: duelo._id,
					username: duelo.usuarioRival,
					estado: duelo.estado,
					accion: "rival",
					miEquipo: duelo.equipoRetador,
					equipoOponente: duelo.equipoRival
				};
				misRivales.push(nuevoRival);
			}
		}
	
	    // filtrar posibles duelos (el resto de usuarios)
		let usuarios = BaseDatos.Usuarios.filter(u => u.perfil == "entrenador" && u._id != usuarioActual);
		let misRetos = [];
		
		for(let usuario of usuarios){
		    let esRival = false;
			for(let rival of misRivales){
				if(usuario._id == rival.username){
					esRival = true;
					break;
				}
			}
			
			if(esRival == false){
				let nuevoReto = {
					idDuelo: null,
					username: usuario._id,
					estado: null,
					accion: "reto"
				};
			    misRetos.push(nuevoReto);
			}
		}
		
		let entrenadores = [];
		
		for(let rival of misRivales){
			entrenadores.push(rival);
		}
		
		for(let reto of misRetos){
			entrenadores.push(reto);
		}
		
		response.send(entrenadores);
	});

	
	app.post("/pokemonapi/insertarduelo", function(request, response){
	
		let idRetador = request.body.idRetador;
		let idRival = request.body.idRival;
	
		let resultado = clienteBD.insertarDuelo(idRetador, idRival);
		
		response.send(resultado);
	});

	app.post("/pokemonapi/actualizarduelo", function(request, response){
		// recoger datos del cliente
		let idDuelo = request.body.idDuelo;
		let nuevoEstado = request.body.nuevoEstado;
		let idGanador = request.body.idGanador;
		let equipoRetador = request.body.equipoRetador;
		let equipoRival = request.body.equipoRival;
		
		let resultado = clienteBD.actualizarDuelo(idDuelo, nuevoEstado, idGanador, equipoRetador, equipoRival);
		
		console.log(`idGanador: ${idGanador}`);
		
		response.send(resultado);
	});
	
	app.get("/pokemonapi/listarpokemonesusuarioequipo", function(request, response){
	
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		let equipo = request.query.equipo; // parámetro de la URL
		
		// resultado final
		let misPokemones = [];
		
		// filtrar ids de pokemones dado el id de usuario
		let pokemonesUsuario = 
			BaseDatos.PokemonesUsuarios.filter(pu => pu.idUsuario == usuarioActual && pu.equipo == equipo);
			
		if(pokemonesUsuario.length > 0){
			// buscar cada pokemon dado su id y agregarlo al resultado
			for(pu of pokemonesUsuario){
				let pokemones = BaseDatos.Pokemones.filter(p => p._id == pu.idPokemon);
				if(pokemones.length > 0){
					let pokemon = pokemones[0];
					pokemon.equipo = pu.equipo; // agregar el dato del equipo al resto de información
					pokemon.entrenador = pu.idUsuario; // también el entrenador ...
					misPokemones.push(pokemon);
				}
			}
		}
		
		response.send(misPokemones);
	});
	

	app.get("/pokemonapi/misequipos", function(request, response){
		let usuarioActual = request.query.idUsuario; // parámetro de la URL
		
		// primero, filtrar mis pokemones
		let pokemonesUsuarios = BaseDatos.PokemonesUsuarios.filter(pu => pu.idUsuario == usuarioActual);
		let misEquipos = []; // Ejemplo: { equipo: "ash-1", pokemones: [ ... ] }
		
		// luego, rellenar mis equipos con los pokemones respectivos
		for(let pU of pokemonesUsuarios){
			let equipo = pU.equipo;
			let idPokemon = pU.idPokemon;
			
			// buscar la info del pokemon
			let infoPokemon = BaseDatos.Pokemones.filter(p => p._id == idPokemon);
			infoPokemon = infoPokemon[0];
			
			// si no hemos agregado este equipo, agregarlo, si sí, agregarle el pokemon nada más
			let buscarEquipo = misEquipos.filter(e => e.equipo == equipo);
			if(buscarEquipo.length == 0){
				let nuevoEquipo = {
					equipo: equipo,
					pokemones: [infoPokemon]
				};
				misEquipos.push( nuevoEquipo );
			}
			else{
				let equipoExistente = buscarEquipo[0];
				equipoExistente.pokemones.push(infoPokemon);
			}
		}
		
		response.send(misEquipos);
	});
	
	
	app.post("/pokemonapi/insertarpokemonusuario", async function(request, response){
	
		let idUsuario = request.body.idUsuario;
		let idPokemon = request.body.idPokemon;
		let equipo = request.body.equipo;
		
		let resultado = 
			clienteBD.insertarPokemonUsuario(idUsuario, idPokemon, equipo);
			
		response.send( {message: "Registro agregado!!" } );
	});
	
	
	app.post("/pokemonapi/eliminarpokemonusuario", async function(request, response){
	
		let idUsuario = request.body.idUsuario;
		let idPokemon = request.body.idPokemon;
		let equipo = request.body.equipo;
		
		let resultado = 
			clienteBD.eliminarPokemonUsuario(idUsuario, idPokemon, equipo);
			
		response.send( {message: "Registro agregado!!" } );
	});
	
	app.get("/pokemonapi/generarincognito", function(request, response){
	
		var usernameAleatorio = "U-" + Math.floor(Math.random() * 1000);		
	
		let nuevoUsuario = clienteBD.insertarUsuario(usernameAleatorio, null, "Incógnito", null); // sólo username (y _id) y perfil
		
		response.send(nuevoUsuario);
	});
	
	app.get("/pokemonapi/eliminarincognito", function(request, response){
	
		var idUsuario = request.query.idUsuario;
		
		let respuesta = clienteBD.eliminarUsuario(idUsuario);

		response.send({message: respuesta});
	});
	
	app.post("/pokemonapi/enviarcorreo", async function(request, response){
	
		let de = request.body.de;
		let para = request.body.para;
		let mensaje = request.body.mensaje;
		
		await mandarCorreo(de, para, mensaje);
		
		response.send("Correo enviado!");	
	});
}


async function mandarCorreo(de, para, mensaje){
	// Generate SMTP service account from ethereal.email
	nodemailer.createTestAccount((err, account) => {
	    if (err) {
	        console.error('Failed to create a testing account. ' + err.message);
	        return process.exit(1);
	    }

	    console.log('Credentials obtained, sending message...');

	    // Create a SMTP transporter object
	    const transporter = nodemailer.createTransport({
			host: 'smtp.ethereal.email',
			port: 587,
			auth: {
				user: 'alexander.spencer20@ethereal.email',
				pass: 'VTs5HUH3GmfsWeXfeY'
			}
		});

	    // Message object
	    let message = {
	        from: `Sender Name <${de}>`,
	        to: `Recipient <${para}>`,
	        subject: 'Proyecto de Ingeniería de Software 1',
	        text: mensaje,
	        html: `<h1>${mensaje}</h1>`
	    };

	    transporter.sendMail(message, (err, info) => {
	        if (err) {
	            console.log('Error occurred. ' + err.message);
	            return process.exit(1);
	        }

	        console.log('Message sent: %s', info.messageId);
	        // Preview only available when sending through an Ethereal account
	        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
	    });
	});
}








