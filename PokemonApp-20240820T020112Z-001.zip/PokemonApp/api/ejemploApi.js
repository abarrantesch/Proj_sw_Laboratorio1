

module.exports = function(app){
	
	// app.get( "URL", function(request, response){} );
	// app.post( "URL", function(request, response){} );
	
	let tablaBichos = [
		{ _id: "A", nombre: "Pikachu", tipo: "Fuego", fuerza: 8.5, velocidad: 8.0, edad: 5, imagen: "/img/pikachu.png"},
		{ _id: "B", nombre: "Bulbasor", tipo: "Tierra", fuerza: 7.5, velocidad: 8.5, edad: 5, imagen: "/img/bulbasor.png"},
		{ _id: "C", nombre: "Charmander", tipo: "Agua", fuerza: 9.3, velocidad: 6.8, edad: 12, imagen: "/img/charmander.png"}
	];
	
	app.get("/api/decirhora", function(request, response){
	
		let horaActual = new Date();
		
		let respuesta = `Según mis cálculos, la hora actual es: ${horaActual}`;
		
		response.send( respuesta );
		
	});
	
	
	app.get("/api/obtenerbichos", function(request, response){
		response.send(tablaBichos);
	});

	app.post("/api/guardarbicho", function(request, response){
	
		// recoger los datos enviados desde el formulario
		let nombre = request.body.nombre
		let tipo = request.body.tipo
		let fuerza = request.body.fuerza
		let velocidad = request.body.velocidad
		let edad = request.body.edad
		
		// crear un nuevo objeto tipo "Bicho"
		let nuevoBicho = {
			_id: "Bicho-" + Math.floor(Math.random() * 1000),
			nombre: nombre,
			tipo: tipo, /* Fuego|Agua|Aire|Tierra */
			fuerza: fuerza,
			velocidad: velocidad,
			edad: edad,
			imagen: null
		};
		
		// meter en la "tabla" el nuevo registro
		tablaBichos.push(nuevoBicho);
		
		// enviar una respuesta al cliente
		let cantidadDeFilas = tablaBichos.length;
		let respuesta = `El bicho ha sido ingresado exitosamente, ahora hay ${cantidadDeFilas} bichos`;
		
		response.send(respuesta);
	});
	
}






