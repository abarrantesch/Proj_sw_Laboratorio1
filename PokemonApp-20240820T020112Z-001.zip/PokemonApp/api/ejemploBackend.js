
module.exports = function(app){

	let tablaUsuarios = [
		{_id: "A", nombre:"Administrador", pais:"CR", user:"admin", passw:"123", perfil:"admin"},
		{_id: "B", nombre:"Pepe", pais:"MX", user:"pepe", passw:"456", perfil:"user"},
		{_id: "C", nombre:"Felix", pais:"CO", user:"felix", passw:"789", perfil:"user"}
	];
	
	let usuarioActual = null;   // simular una "sesión"
	
	app.post("/api/login", function(request, response){
	
		// obtener los datos enviados por input
		let user = request.body.user;
		let passw = request.body.passw;
		
		console.log(`usuario recibido: ${user}, contraseña recibida: ${passw}`);
		
		let usuarios = tablaUsuarios.filter(u => (u.user == user && u.passw == passw) );
		/*let usuarios = [];
		for(let u of tablaUsuarios){
			if(u.user == user && u.passw == passw){
				usuarios.push();
			}
		}*/
	
		if(usuarios.length == 0){
			response.send("Error");
		}
		else{
			usuario = usuarios[0];
			usuarioActual = usuario;	// actualizar la "sesión" actual
			response.send("OK");
		}
	
	} );


	app.get("/api/obtenerusuario", function(request, response){
	
		if(usuarioActual.perfil == "admin"){
			response.send(tablaUsuarios);
		}
		else{
			response.send( [usuarioActual] );
		}
	
	} );
}








