
/* En la práctica, la configuración de acceso a la BD se guarda en lugares externos,
no directamente en el código y mucho menos que sea inteligible (sin encriptar u ofuscada).
En este curso no importa si lo manejamos directamente aquí, pero recuérdenlo... */
let dbConfig = {
	// Connection string, todas las bases de datos tienen al menos una ruta de acceso remoto
	connectionString: "mongodb://127.0.0.1:27017/PokemonApp"
};

// Importar biblioteca de Mongo y de paso extraer el cliente
let {MongoClient} = require("mongodb");
 // El ObjectId sirve para obtener el _id generado por Mongo y pasarlo a String
let ObjectId = require("mongodb").ObjectId;

// Instanciamos un cliente de base de datos dado un connectionString
let mongodb = new MongoClient( dbConfig.connectionString );

module.exports = function(){

	let connection = null;
	let Pokemones = [];
	let Usuarios = [];
	let PokemonesUsuarios = [];
	let Duelos = [];
	let DetalleDuelos = [];
	this.db = null;
	
	let estaClase = this;
	
	this.conectarBaseDatos = async function(){
		// Conexión a la base de datos
		connection = await mongodb.connect();
		// Obtención de las tablas
		Pokemones = await connection.db("PokemonApp").collection("Pokemones");
		Usuarios = await connection.db("PokemonApp").collection("Usuarios");
		PokemonesUsuarios = await connection.db("PokemonApp").collection("PokemonesUsuarios");
		Duelos = await connection.db("PokemonApp").collection("Duelos");
		DetalleDuelos = await connection.db("PokemonApp").collection("DetalleDuelos");
		
		estaClase.db = {
			Pokemones: Pokemones,
			Usuarios: Usuarios,
			PokemonesUsuarios: PokemonesUsuarios,
			Duelos: Duelos,
			DetalleDuelos: DetalleDuelos	
		};
	}
	
	this.desconectarBaseDatos = function(){
		connecion.close();
		connection = null;
	}

	// CRUD: Create, Read, Update, Delete

	this.insertarPokemon = async function(nom, tip, fuer, veloc, eda, ima){
		let nuevoPokemon = {
			_id: "P-" + Math.floor(Math.random() * 1000), /*new ObjectId().toString()*/
			nombre: nom,
			tipo: tip, /* Fuego|Agua|Aire|Tierra */
			fuerza: fuer,
			velocidad: veloc,
			edad: eda,
			imagen: ima
		};
		
		//console.log(Pokemones);
		
		let respuesta = await Pokemones.insertOne(nuevoPokemon);

		return nuevoPokemon;
	}

	this.insertarUsuario = async function(usr, passw, perf, fot){
		let nuevoUsuario = {
			//_id: "U-" + Math.floor(Math.random() * 1000), /*new ObjectId().toString()*/
			_id: usr,
			username: usr,
			password: passw,
			perfil: perf,
			foto: fot,
			enlinea: false
		};
		
		let respuesta = await Usuarios.insertOne(nuevoUsuario);

		return nuevoUsuario;
	}

	this.insertarPokemonUsuario = async function(idUsuario, idPokemon, equipo){

		let nuevoPokemonUsuario = {
			idUsuario: idUsuario,
			idPokemon: idPokemon,
			equipo: equipo
		};
		
		let respuesta = await PokemonesUsuarios.insertOne(nuevoPokemonUsuario);

		return respuesta;
	}

	this.insertarDuelo = async function(usuarioRetador, usuarioRival){
		let nuevoDuelo = {
			_id: "D-" + Math.floor(Math.random() * 1000),	/*new ObjectId().toString()*/
			usuarioRetador: usuarioRetador,
			usuarioRival: usuarioRival,
			estado: "Inv",  /* Inv | Ace | Rec | EnP | Fin */
			usuarioGanador: null,
			equipoRetador: null,
			equipoRival: null,			// usuarioGanador y equipos se llenarán cuando jueguen
		};
		
		let respuesta = await Duelos.insertOne(nuevoDuelo);

		return respuesta;
	}

	async function insertarDetalleDuelo(idDuelo, pokemonRetador, pokemonRival){
		let nuevoDetalleDuelo = {
			idDuelo: idDuelo,
			pokemonRetador: pokemonRetador,
			pokemonRival: pokemonRival
		};
		
		let respuesta = await DetalleDuelos.insertOne(nuevoDetalleDuelo);

		return respuesta;
	}
	
	
	this.actualizarPokemon = async function(_id, nom, tip, fuer, veloc, eda, ima){
		let editarPokemon = {
			nombre: nom,
			tipo: tip,
			fuerza: fuer,
			velocidad: veloc,
			edad: eda
		};
		
		if(ima != ""){
			editarPokemon.imagen = ima;
		}
		
		let respuesta = await Pokemones.updateOne( { _id: _id }, { $set: editarPokemon } );

		return respuesta;
	}
	
	
	//function actualizarDuelo(idDuelo, nuevoEstado, idGanador){
	this.actualizarDuelo = async function(idDuelo, nuevoEstado, idGanador, equipoRetador, equipoRival){
		/* Inv | Ace | Rec | Esp | Jug | Pro | Fin */
		let duelos = await Duelos.find( {_id: idDuelo } ).toArray();
		
		if(duelos.length > 0){	// si hay un duelo con ese id
			let duelo = {}; //duelos[0];
			let respuesta = {};
			if(nuevoEstado == "Rec" || nuevoEstado == "Can"){	// Rechazado o Cancelado, lo eliminamos
				//delete duelo;
				respuesta = await Duelos.deleteOne( {_id: idDuelo } );
			}
			else{
				duelo.estado = nuevoEstado;
				if(equipoRetador != ""){
					duelo.equipoRetador = equipoRetador;
				}
				if(equipoRival != ""){
					duelo.equipoRival = equipoRival;
				}
				if(idGanador != "" && idGanador != undefined){
					duelo.usuarioGanador = idGanador;
				}
				respuesta = await Duelos.updateOne( { _id: idDuelo }, { $set: duelo } );
			}
			return respuesta;
		}
		else{	// sino
			return false;
		}
		
	}

	
	this.eliminarPokemonUsuario = async function(idUsuario, idPokemon, equipo){
		let respuesta = await PokemonesUsuarios.deleteOne( {idUsuario: idUsuario, idPokemon: idPokemon, equipo: equipo} );
	
		return respuesta;
	}
	

	this.eliminarUsuario = async function(idUsuario){
	
		// borrar toda referencia al usuario incógnito
		await Usuarios.deleteOne( { _id: idUsuario } );
		await PokemonesUsuarios.deleteMany( { idUsuario: idUsuario } );
		// el siguiente filtro es equivalente a usuarioRetador == idUsuario || usuarioRival == idUsuario
		await Duelos.deleteMany( { $or: [ { usuarioRetador: idUsuario }, { usuarioRival: idUsuario } ] } );
		
		return true;
	}
	
}

