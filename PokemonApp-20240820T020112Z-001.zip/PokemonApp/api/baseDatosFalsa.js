

module.exports = function(){

	this.BaseDatos = {
		Pokemones: [],
		Usuarios: [],
		PokemonesUsuarios: [],
		Duelos: [],
		DetalleDuelos: []	
	};
	
	let estaClase = this;

	// CRUD: Create, Read, Update, Delete

	this.insertarPokemon = function(nom, tip, fuer, veloc, eda, ima){
		let nuevoPokemon = {
			_id: "P-" + Math.floor(Math.random() * 1000),
			nombre: nom,
			tipo: tip, /* Fuego|Agua|Aire|Tierra */
			fuerza: fuer,
			velocidad: veloc,
			edad: eda,
			imagen: ima
		};
		estaClase.BaseDatos.Pokemones.push( nuevoPokemon );

		return nuevoPokemon;
	}

	this.insertarUsuario = function(usr, passw, perf, fot){
		let nuevoUsuario = {
			//_id: "U-" + Math.floor(Math.random() * 1000),
			_id: usr,
			username: usr,
			password: passw,
			perfil: perf,
			foto: fot,
			enlinea: false
		};
		estaClase.BaseDatos.Usuarios.push( nuevoUsuario );

		return nuevoUsuario;
	}

	this.insertarPokemonUsuario = function(idUsuario, idPokemon, equipo){

		let nuevoPokemonUsuario = {
			idUsuario: idUsuario,
			idPokemon: idPokemon,
			equipo: equipo
		};
		estaClase.BaseDatos.PokemonesUsuarios.push( nuevoPokemonUsuario );
	}

	this.insertarDuelo = function(usuarioRetador, usuarioRival){
		let nuevoDuelo = {
			_id: "D-" + Math.floor(Math.random() * 1000),
			usuarioRetador: usuarioRetador,
			usuarioRival: usuarioRival,
			estado: "Inv",  /* Inv | Ace | Rec | EnP | Fin */
			usuarioGanador: null,
			equipoRetador: null,
			equipoRival: null,			// usuarioGanador y equipos se llenarán cuando jueguen
		};
		estaClase.BaseDatos.Duelos.push( nuevoDuelo );
	}

	function insertarDetalleDuelo(idDuelo, pokemonRetador, pokemonRival){
		let nuevoDetalleDuelo = {
			idDuelo: idDuelo,
			pokemonRetador: pokemonRetador,
			pokemonRival: pokemonRival
		};
		estaClase.BaseDatos.DetalleDuelos.push( nuevoDetalleDuelo );
	}
	
	
	this.actualizarPokemon = function(_id, nom, tip, fuer, veloc, eda, ima){
		let editarPokemon = estaClase.BaseDatos.Pokemones.filter(p => p._id == _id);
		
		console.log(ima);
		if(editarPokemon.length == 0){
			return false;
		}
		
		editarPokemon = editarPokemon[0];
		
		editarPokemon.nombre = nom;
		editarPokemon.tipo = tip;
		editarPokemon.fuerza = fuer,
		editarPokemon.velocidad = veloc,
		editarPokemon.edad = eda;
		
		if(ima != ""){
			editarPokemon.imagen = ima;
		}

		return true;
	}
	
	
	//function actualizarDuelo(idDuelo, nuevoEstado, idGanador){
	this.actualizarDuelo = function(idDuelo, nuevoEstado, idGanador, equipoRetador, equipoRival){
		/* Inv | Ace | Rec | Esp | Jug | Pro | Fin */
		let duelos = estaClase.BaseDatos.Duelos.filter(d => d._id == idDuelo);
		
		if(duelos.length > 0){	// si hay un duelo con ese id
			let duelo = duelos[0];
			if(nuevoEstado == "Rec" || nuevoEstado == "Can"){	// Rechazado o Cancelado, lo eliminamos
				//delete duelo;
				let duelosEliminandoElActual = estaClase.BaseDatos.Duelos.filter(d => d._id != idDuelo);
				estaClase.BaseDatos.Duelos = duelosEliminandoElActual;
			}
			else{
				duelo.estado = nuevoEstado;
				if(equipoRetador != ""){
					duelo.equipoRetador = equipoRetador;
				}
				if(equipoRival != ""){
					duelo.equipoRival = equipoRival;
				}
				if(idGanador != "" && idGanador != undefined){
					duelo.usuarioGanador = idGanador;
				}
			}
			
			console.log(duelo);
			return true;
		}
		else{	// sino
			return false;
		}
	}

	
	this.eliminarPokemonUsuario = function(idUsuario, idPokemon, equipo){
		estaClase.BaseDatos.PokemonesUsuarios = 
		  estaClase.BaseDatos.PokemonesUsuarios.filter(pU => !(pU.idUsuario == idUsuario && pU.idPokemon == idPokemon && pU.equipo == equipo));
	
		return true;
	}
	

	this.eliminarUsuario = function(idUsuario){
	
		// borrar toda referencia al usuario incógnito
		estaClase.BaseDatos.Usuarios = estaClase.BaseDatos.Usuarios.filter(u => u._id != idUsuario);
		estaClase.BaseDatos.PokemonesUsuarios = estaClase.BaseDatos.PokemonesUsuarios.filter(pU => pU.idUsuario != idUsuario);
		estaClase.BaseDatos.Duelos = estaClase.BaseDatos.Duelos.filter(d => d.usuarioRetador != idUsuario || d.usuarioRival != idUsuario);
		
		return true;
	}
	
    this.cargarDatosPrueba = function(){
		let pikachu = this.insertarPokemon("Pikachu", "Fuego", 8.5, 8.0, 5, "/img/pikachu.png");
		let bulbasor = this.insertarPokemon("Bulbasor", "Tierra", 7.5, 8.5, 5, "/img/bulbasor.png");
		let charmander = this.insertarPokemon("Charmander", "Agua", 9.3, 6.8, 12, "/img/charmander.png");
		let squirtle = this.insertarPokemon("Squirtle", "Aire", 6.5, 8.0, 9, "/img/squirtle.png");
		let chrizard = this.insertarPokemon("Chrizard", "Fuego", 8.5, 8.0, 8, "/img/chrizard.png");
		let rattata = this.insertarPokemon("Rattata", "Tierra", 7.9, 7.2, 15, "/img/rattata.png");
		
		let pikachu2 = this.insertarPokemon("Pikachu 2", "Fuego", 7.5, 8.0, 8, "/img/pikachu2.png");
		let bulbasor2 = this.insertarPokemon("Bulbasor 2", "Tierra", 8.5, 8.5, 5, "/img/bulbasor2.png");
		let charmander2 = this.insertarPokemon("Charmander 2", "Agua", 9.3, 6.8, 12, "/img/charmander2.png");
		let squirtle2 = this.insertarPokemon("Squirtle 2", "Aire", 6.5, 7.9, 9, "/img/squirtle2.png");
		let chrizard2 = this.insertarPokemon("Chrizard 2", "Fuego", 8.5, 8.0, 5, "/img/chrizard2.png");
		let rattata2 = this.insertarPokemon("Rattata 2", "Tierra", 8.0, 7.2, 15, "/img/rattata2.png");
		
		let ash = estaClase.insertarUsuario("ash", "123", "entrenador", "/img/pikachu.png");
		let misty = estaClase.insertarUsuario("misty", "456", "entrenador", "/img/squirtle.png");
		let brock = estaClase.insertarUsuario("brock", "789", "entrenador", "/img/chrizard2.png");
		let teniente = estaClase.insertarUsuario("teniente", "987", "entrenador", "/img/charmander2.png");
		let erika = estaClase.insertarUsuario("erika", "654", "entrenador", "/img/bulbasor2.png");
		let ash2 = estaClase.insertarUsuario("ash2", "123", "entrenador", "/img/pikachu.png");
		let misty2 = estaClase.insertarUsuario("misty2", "456", "entrenador", "/img/squirtle.png");
		let brock2 = estaClase.insertarUsuario("brock2", "789", "entrenador", "/img/chrizard2.png");
		let teniente2 = estaClase.insertarUsuario("teniente2", "987", "entrenador", "/img/charmander2.png");
		let erika2 = estaClase.insertarUsuario("erika2", "654", "entrenador", "/img/bulbasor2.png");

		estaClase.insertarPokemonUsuario(ash._id, pikachu._id, "ash-1");
		estaClase.insertarPokemonUsuario(ash._id, bulbasor._id, "ash-1");
		estaClase.insertarPokemonUsuario(ash._id, charmander._id, "ash-1");
		estaClase.insertarPokemonUsuario(ash._id, squirtle._id, "ash-1");
		estaClase.insertarPokemonUsuario(ash._id, chrizard._id, "ash-1");
		estaClase.insertarPokemonUsuario(ash._id, rattata._id, "ash-1");

		estaClase.insertarPokemonUsuario(misty._id, pikachu2._id, "misty-1");
		estaClase.insertarPokemonUsuario(misty._id, bulbasor2._id, "misty-1");
		estaClase.insertarPokemonUsuario(misty._id, charmander2._id, "misty-1");
		estaClase.insertarPokemonUsuario(misty._id, squirtle2._id, "misty-1");
		estaClase.insertarPokemonUsuario(misty._id, chrizard2._id, "misty-1");
		estaClase.insertarPokemonUsuario(misty._id, rattata2._id, "misty-1");
		
		
		estaClase.insertarDuelo(ash._id, misty._id);
		estaClase.insertarDuelo(brock._id, ash._id);
	}
}

