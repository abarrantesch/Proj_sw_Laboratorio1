
let BaseDatosVerdadera = require("./BaseDatosVerdadera");

function MiClase(){

	let clienteBD = new BaseDatosVerdadera();
	let db = null;
	
    this.cargarDatosPrueba = async function(){
	
		await clienteBD.conectarBaseDatos();
		db = clienteBD.db;
	
	    // limpiar las tablas antes de volverlas a cargar
		await db.Pokemones.deleteMany({});
		await db.Usuarios.deleteMany({});
		await db.PokemonesUsuarios.deleteMany({});
		await db.Duelos.deleteMany({});
		await db.DetalleDuelos.deleteMany({});
	/*return;*/
		let pikachu = await clienteBD.insertarPokemon("Pikachu", "Fuego", 8.5, 8.0, 5, "/img/pikachu.png");
		let bulbasor = await clienteBD.insertarPokemon("Bulbasor", "Tierra", 7.5, 8.5, 5, "/img/bulbasor.png");
		let charmander = await clienteBD.insertarPokemon("Charmander", "Agua", 9.3, 6.8, 12, "/img/charmander.png");
		let squirtle = await clienteBD.insertarPokemon("Squirtle", "Aire", 6.5, 8.0, 9, "/img/squirtle.png");
		let chrizard = await clienteBD.insertarPokemon("Chrizard", "Fuego", 8.5, 8.0, 8, "/img/chrizard.png");
		let rattata = await clienteBD.insertarPokemon("Rattata", "Tierra", 7.9, 7.2, 15, "/img/rattata.png");
		
		let pikachu2 = await clienteBD.insertarPokemon("Pikachu 2", "Fuego", 7.5, 8.0, 8, "/img/pikachu2.png");
		let bulbasor2 = await clienteBD.insertarPokemon("Bulbasor 2", "Tierra", 8.5, 8.5, 5, "/img/bulbasor2.png");
		let charmander2 = await clienteBD.insertarPokemon("Charmander 2", "Agua", 9.3, 6.8, 12, "/img/charmander2.png");
		let squirtle2 = await clienteBD.insertarPokemon("Squirtle 2", "Aire", 6.5, 7.9, 9, "/img/squirtle2.png");
		let chrizard2 = await clienteBD.insertarPokemon("Chrizard 2", "Fuego", 8.5, 8.0, 5, "/img/chrizard2.png");
		let rattata2 = await clienteBD.insertarPokemon("Rattata 2", "Tierra", 8.0, 7.2, 15, "/img/rattata2.png");
		
		let ash = await clienteBD.insertarUsuario("ash", "123", "entrenador", "/img/ash.png");
		let misty = await clienteBD.insertarUsuario("misty", "456", "entrenador", "/img/misty.png");
		let brock = await clienteBD.insertarUsuario("brock", "789", "entrenador", "/img/chrizard2.png");
		let teniente = await clienteBD.insertarUsuario("teniente", "987", "entrenador", "/img/charmander2.png");
		let erika = await clienteBD.insertarUsuario("erika", "654", "entrenador", "/img/bulbasor2.png");
		let ash2 = await clienteBD.insertarUsuario("ash2", "123", "entrenador", "/img/pikachu.png");
		let misty2 = await clienteBD.insertarUsuario("misty2", "456", "entrenador", "/img/squirtle.png");
		let brock2 = await clienteBD.insertarUsuario("brock2", "789", "entrenador", "/img/chrizard2.png");
		let teniente2 = await clienteBD.insertarUsuario("teniente2", "987", "entrenador", "/img/charmander2.png");
		let erika2 = await clienteBD.insertarUsuario("erika2", "654", "entrenador", "/img/bulbasor2.png");

		await clienteBD.insertarPokemonUsuario(ash._id, pikachu._id, "ash-1");
		await clienteBD.insertarPokemonUsuario(ash._id, bulbasor._id, "ash-1");
		await clienteBD.insertarPokemonUsuario(ash._id, charmander._id, "ash-1");
		await clienteBD.insertarPokemonUsuario(ash._id, squirtle._id, "ash-1");
		await clienteBD.insertarPokemonUsuario(ash._id, chrizard._id, "ash-1");
		await clienteBD.insertarPokemonUsuario(ash._id, rattata._id, "ash-1");

		await clienteBD.insertarPokemonUsuario(misty._id, pikachu2._id, "misty-1");
		await clienteBD.insertarPokemonUsuario(misty._id, bulbasor2._id, "misty-1");
		await clienteBD.insertarPokemonUsuario(misty._id, charmander2._id, "misty-1");
		await clienteBD.insertarPokemonUsuario(misty._id, squirtle2._id, "misty-1");
		await clienteBD.insertarPokemonUsuario(misty._id, chrizard2._id, "misty-1");
		await clienteBD.insertarPokemonUsuario(misty._id, rattata2._id, "misty-1");
		
		
		await clienteBD.insertarDuelo(ash._id, misty._id);
		await clienteBD.insertarDuelo(brock._id, ash._id);
		
		console.log("Datos cargados!");
		process.exit(0);
	}
}

let miObjeto = new MiClase();
setTimeout(async function(){
	await miObjeto.cargarDatosPrueba();
}, 1000);