let express = require("express");
let path = require("path");
let bodyParser = require( "body-parser" );
let multer = require( "multer" );

let app = express();

let directorioActual = __dirname;
let carpetaEstaticos = "webroot";

let directorioEstaticos = path.join( directorioActual, carpetaEstaticos );
app.use(express.static( directorioEstaticos ));
console.log( "Directorio archivos estáticos: " + directorioEstaticos);

app.use( express.json() );
app.use( express.urlencoded() );
app.use(multer({ dest: `${carpetaEstaticos}/uploads/` }).any());


// incorporar el archivo que contiene la api
let ejemploApi = require("./api/ejemploApi")(app);
let ejemploBackend = require("./api/ejemploBackend")(app);
let pokemonAPI = require("./api/pokemonAPI")(app);


let ipServidor = "0.0.0.0";
let puertoServidor = 80;

let servidor = app.listen( puertoServidor, ipServidor,  function ( ) {
    console.log( "Servidor corriendo en http://localhost:" + puertoServidor + "/" );
});
