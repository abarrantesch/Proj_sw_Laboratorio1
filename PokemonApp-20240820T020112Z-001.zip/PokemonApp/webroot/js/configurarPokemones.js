
function MostrarDetalle(idObjeto){
	var columnaOculta = document.querySelector( `#${idObjeto}` );
	var pokemonString = columnaOculta.innerHTML;
	sessionStorage.setItem("pokemonActual", pokemonString);
	location.href = "/configuracion/pokemones/detalle.html";
}

function MostrarNuevo(){
	sessionStorage.removeItem("pokemonActual");
	location.href = "/configuracion/pokemones/detalle.html";
}

async function CargarTabla(){

	var respuestaServidor = await fetch("/pokemonapi/listarpokemones");
	var pokemones = await respuestaServidor.json();

	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	for(var o of pokemones){
		var objetoString = JSON.stringify(o);
		var nuevaFila = `<tr>
			<td>${o._id}</td>
			<td>${o.nombre}</td>
			<td>${o.tipo}</td>
			<td id="${o._id}" style="display: none;">${objetoString}</td>
			<td> <i class="fa-solid fa-pencil" onclick=" MostrarDetalle('${o._id}'); "></i> </td>
			
		</tr>`;
		
		contenidoTabla.innerHTML += nuevaFila;
	}
}

async function ValidarFormulario(){

	event.preventDefault();

	var formulario = document.querySelector(".contenedorFormulario form");

	var inputId = formulario.querySelector("input[name='_id']");
	var inputNombre = formulario.querySelector("input[name='nombre']");

	var spanNombre = formulario.querySelector("span[id='validarNombre']");
	spanNombre.style.display = "none";

    var bordeNormal = "1px solid var(--moradoPopular1)";
	inputNombre.style.borderBottom = bordeNormal;

	var resultadoValidacion = true;

	/* validar nombre no vacío */
	var textoNombre = inputNombre.value;
	if(textoNombre.trim() == ""){
		spanNombre.style.display = "block";
		inputNombre.style.borderBottom = "2px solid red";
		//return false;
		resultadoValidacion = false;
	}
	
	
	var datosFormulario = new FormData(formulario);// multipart

	var url = "?";
	var pokemonStr = sessionStorage.getItem("pokemonActual");
	if(pokemonStr != null){
		url = "/pokemonapi/actualizarpokemon";
	}
	else{
		url = "/pokemonapi/insertarpokemon";
	}

	
	var respuestaServidor = await fetch(url, 
										{method: "post", body: datosFormulario});
	var respuesta = await respuestaServidor.json();
	
	Swal.fire({
		title: "Pokemones",
		text: respuesta.message,
		icon: "success"
	});

	return resultadoValidacion;
}

window.onload = function(){

	var paginaActual = document.querySelector("#scriptActual").getAttribute("paginaActual");

	if(paginaActual == "listado"){
		CargarTabla();
	}
	else if(paginaActual == "detalle"){

		var formulario = document.querySelector(".contenedorFormulario form");
		var inputId = formulario.querySelector("input[name='_id']");
		var inputNombre = formulario.querySelector("input[name='nombre']");
		var inputTipo = formulario.querySelector("input[name='tipo']");
		var selectFuerza = formulario.querySelector("select[name='fuerza']");
		var selectVelocidad = formulario.querySelector("select[name='velocidad']");
		var selectEdad = formulario.querySelector("select[name='edad']");
		
		var inputImagen = document.querySelector(".contenedorFormulario input[type='file']");
		var imagenPreview = document.querySelector(".imagenPreview");

		inputImagen.addEventListener("change", function(evt){
			const [file] = inputImagen.files;
			if(file){
				imagenPreview.src = URL.createObjectURL(file);
			}
		});
		
		
		var pokemonString = sessionStorage.getItem("pokemonActual");
		var pokemon = JSON.parse(pokemonString);
		
		if(pokemon != null){ // EDITAR

			inputId.value = pokemon._id;
			inputNombre.value = pokemon.nombre;
			inputTipo.value = pokemon.tipo;
			selectFuerza.value = pokemon.fuerza;
			selectVelocidad.value = pokemon.velocidad;
			selectEdad.value = pokemon.edad;
			imagenPreview.src = pokemon.imagen;
		}
		else{	// AGREGAR
		}		
	}
}




