//Hacer el Login

var tablaUsuarios = [
	{usuario: "uPamela", contrasena: "123"},
	{usuario: "bbb", contrasena: "456"},
	{usuario: "ccc", contrasena: "789"}
];

function Login(formulario){

    var formulario = document.querySelector(".container .container-form");
	var inputUsuario = formulario.querySelector("input[name='email']");
	var inputContrasena = formulario.querySelector("input[name='password']");
	
	var encontrado = false;
	for(var u of tablaUsuarios){
		if(inputUsuario.value.trim() == u.usuario && inputContrasena.value.trim() == u.contrasena){
			// encontró un usuario con la combinación
			// vamos a guardarlo en el sessionStorage, hay que pasar el objeto a string
			var usuarioString = JSON.stringify(u);
			sessionStorage.setItem("UsuarioLogueado", usuarioString);
			
			encontrado = true;
			
			// nos pasamos a la página destino
			location.href = "/index.html";
		}
	}
	
	if(encontrado == false){
		Swal.fire({
		  title: "Login falló",
		  text: "Datos incorrectos.",
		  icon: "error"
		});	
	}
}


function ValidarLogin(){

	event.preventDefault();

	var formulario = document.querySelector(".container .container-form");
	var inputCorreo= formulario.querySelector("input[name='email']");
	var inputContrasena = formulario.querySelector("input[name='password']");
	
	if(inputCorreo.value.trim() == ""){
		return false;
	}
	
	if(inputContrasena.value.trim() == ""){
		return false;
	}
	
	Login(formulario);
	return true;
}


/* Función "principal" (main) ... */
window.onload = function(){
	// ...
   
   ValidarLogin();
   Login();
   
}