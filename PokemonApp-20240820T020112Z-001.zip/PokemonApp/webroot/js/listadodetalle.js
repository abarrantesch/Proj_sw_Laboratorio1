
var tablaObjetos = [
	{_id: "AAA", nombre: "AAA", salario: 5000},
	{_id: "BBB", nombre: "BBB", salario: 6500},
	{_id: "CCC", nombre: "CCC", salario: 8060}
];


function MostrarDetalle(idObjeto){
	var columnaOculta = document.querySelector( `#${idObjeto}` );
	var objetoString = columnaOculta.innerHTML;
	sessionStorage.setItem("objetoActual", objetoString);
	location.href = "/listadodetalle/detalle.html";
}

function CargarTabla(){

	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	for(var o of tablaObjetos){
		var objetoString = JSON.stringify(o);
		var nuevaFila = `<tr>
			<td>${o._id}</td>
			<td>${o.nombre}</td>
			<td>${o.salario}</td>
			<td id="${o._id}" style="display: none;">${objetoString}</td>
			<td> <input type="button" value="Editar" onclick=" MostrarDetalle('${o._id}'); "> </td>
		</tr>`;
		
		contenidoTabla.innerHTML += nuevaFila;
	}
}

window.onload = function(){

	var paginaActual = document.querySelector("#scriptActual").getAttribute("paginaActual");

	if(paginaActual == "listado"){
		CargarTabla();
	}
	else if(paginaActual == "detalle"){
		var objetoString = sessionStorage.getItem("objetoActual");
		var objeto = JSON.parse(objetoString);

		var formulario = document.querySelector(".contenedorFormulario form");
		var inputId = formulario.querySelector("input[name='_id']");
		var inputNombre = formulario.querySelector("input[name='nombre']");
		var inputSalario = formulario.querySelector("input[name='salario']");

		inputId.value = objeto._id;
		inputNombre.value = objeto.nombre;
		inputSalario.value = objeto.salario;
	}
}




