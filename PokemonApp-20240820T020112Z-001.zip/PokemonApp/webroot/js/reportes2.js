
/*async function ReportePosiciones(){

	var respuestaServidor = await fetch("/pokemonapi/reportes/posiciones");	
	var puntajesUsuarios = await respuestaServidor.json();
	
	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	for(var pU of puntajesUsuarios){
		var nuevaFila = `<tr>
			<td>${pU.idUsuario}</td>
			<td>${pU.duelosGanados}</td>
			<td>${pU.duelosPerdidos}</td>
			<td>${pU.puntaje}</td>
		</tr>`;		
		contenidoTabla.innerHTML += nuevaFila;
	}
} */

async function ReportePerfiles(){

	var respuestaServidor = await fetch("/pokemonapi/reportes/reportes2");	
	var perfilUsuarios = await respuestaServidor.json();	
	
	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	for(var p of perfilUsuarios){
		var nuevaFila = `<tr>
			<td>${p._id}</td>
			<td>${p.perfil}</td>
			<td>${p.foto}</td>
		</tr>`;		
		contenidoTabla.innerHTML += nuevaFila;
	}
}

/*async function ReporteGanesPerdidasPokemones(tipo){

	var inputUsername = document.querySelector("#username");
	
	var url = "";
	if(tipo == "ganes"){
		url = "/pokemonapi/reportes/ganesapokemones?idUsuario=" + inputUsername.value;
	}
	else{
		url = "/pokemonapi/reportes/perdidascontrapokemones?idUsuario=" + inputUsername.value;
	}

	var respuestaServidor = await fetch(url);	
	var ganesPerdidas = await respuestaServidor.json();
	console.log(ganesPerdidas);
	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	for(var gP of ganesPerdidas){
		var nuevaFila = `<tr>
			<td>${gP.idPokemon}</td>
			<td>${gP.nombre}</td>
			<td>${gP.duelos}</td>
		</tr>`;		
		contenidoTabla.innerHTML += nuevaFila;
	}
}*/


window.onload = async function(){
	
		ReportePerfiles();
	
}





