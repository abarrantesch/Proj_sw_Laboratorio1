
function ValidarRecuperacion(){
    event.preventDefault( );

    var formularioRegistro = document.querySelector(".container");

    var inputCorreo = formularioRegistro.querySelector("input[name='correo']");
	
    if( inputCorreo.value == "" || inputCorreo.value.includes("@") == false ){
		spanValidarCorreo.style.display = "block";
		return false;
	}

    Swal.fire({
        title: "Buen trabajo!",
        text: "Se ha enviado su nueva contraseña!",
        icon: "success"
      });
      
      return true;

}

/* Función "principal" (main) ... */
window.onload = function(){
	// ...
   
   ValidarRecuperacion();
}