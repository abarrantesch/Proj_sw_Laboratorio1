

async function MostrarReporteDinamico(){
	// Mostrar reporte de las tablas anteriores en una tabla HTML
	var tbody = document.querySelector(".contenedorReporte table tbody");
	
	tbody.innerHTML = "";
	
	var respuestaServidor = await fetch("/api/obtenerbichos");
	var tablaBichos = await respuestaServidor.json();
	
	for(var bicho of tablaBichos){
		var nuevaFila = `<tr>
					<td>${bicho._id}</td>
					<td>${bicho.nombre}</td>
					<td>${bicho.tipo}</td>
					<td>${bicho.fuerza}</td>
					<td>${bicho.velocidad}</td>
					<td>${bicho.edad}</td>
				</tr>`;
		
		tbody.innerHTML += nuevaFila;
	}
}


window.onload = async function(){
	await MostrarReporteDinamico();
};








