
async function ValidarFormularioBicho(){

	event.preventDefault();

	var formularioBicho = document.querySelector(".contenedorFormulario form");
	
	var inputNombre = formularioBicho.querySelector("input[name='nombre']");
	var spanValidarNombre = formularioBicho.querySelector("section.nombre span.validar");
	
	spanValidarNombre.style.display = "none";
	
	if( inputNombre.value == "" ){
		spanValidarNombre.style.display = "block";
		return false;
	}
	
	var datosFormulario = new FormData(formularioBicho);
	
	// enviar solcitud tipo POST al servidor
	var respuestaServidor = await fetch("/api/guardarbicho", { method: "post", body: datosFormulario } );
	
	console.log(respuestaServidor);
	
	
	Swal.fire({
	  title: "Buen trabajo!",
	  text: "Formulario Validado!",
	  icon: "success"
	});
	
	return true;
	
	
}


function CalcularArea( ){

	event.preventDefault();
	
	var inputBase = document.querySelector("section.triangulo input[name='base']");
	var inputAltura = document.querySelector("section.triangulo input[name='altura']");
	var inputArea = document.querySelector("section.triangulo input[name='area']");
	
	var spanValidarBase = document.querySelector("section.triangulo span.validarBase");
	var spanValidarAltura = document.querySelector("section.triangulo span.validarAltura");
	
	spanValidarBase.style.display = "none";
	spanValidarAltura.style.display = "none";
	inputArea.value = "";
	
	if(inputBase.value.trim() == ""){
		spanValidarBase.style.display = "block";
		return;
	}
	
	if(inputAltura.value.trim() == ""){
		spanValidarAltura.innerHTML = "Introduzca un valor para la altura";
		spanValidarAltura.style.display = "block";
		return;
	}
	else{
		var noEsNumerico = isNaN(inputAltura.value); // isNaN: isNotaNumber?
		if(noEsNumerico == true){
			spanValidarAltura.innerHTML = "No se permiten letras en la altura";
			spanValidarAltura.style.display = "block";
			return;
		}
	}
	
	var base = parseInt(  inputBase.value  );
	var altura = parseInt(   inputAltura.value );
	
	var area = (base * altura) / 2;
	
	inputArea.value = area;
	
}


/* Función "principal" (main) ... */
window.onload = function(){
	// ...
}






