var tablaBichos = [];
var tablaEntrenadores = [];
var tablaBichosEntrenador = [];
var tablaDuelos = [];

// CRUD: Create, Read, Update, Delete
function crearBicho(nom, tip, fuer, veloc, eda, ima){
	var nuevoBicho = {
    	_id: "Bicho-" + Math.floor(Math.random() * 1000),
    	nombre: nom,
    	tipo: tip, /* Fuego|Agua|Aire|Tierra */
    	fuerza: fuer,
    	velocidad: veloc,
    	edad: eda,
    	imagen: ima
	};
	tablaBichos.push( nuevoBicho );

	return nuevoBicho;
}

function crearEntrenador(nom){
	var nuevoEntrenador = {
    	_id: "Entrenador-" + Math.floor(Math.random() * 1000),
    	nombre: nom
	};
	tablaEntrenadores.push( nuevoEntrenador );

	return nuevoEntrenador;
}

function crearBichoEntrenador(idEntr, idBic){
	var nuevoBichoEntrenador = {
    	idEntrenador: idEntr,
    	idBicho: idBic
	};
	tablaBichosEntrenador.push( nuevoBichoEntrenador );
}

function crearDuelo(idBic1, idBic2, gan){
	var nuevoDuelo = {
    	idBicho1: idBic1,
    	idBicho2: idBic2,
    	ganador: gan  /* si gan=0 empate, gan=1 idBicho1, sino idBicho2 */
	};
	tablaDuelos.push( nuevoDuelo );
}

function cargarConfiguracion(){
	/* Cargar algunos bichos */
	var pikachu = crearBicho("Pikachu", "Fuego", 8.5, 8.0, 5, "/img/pikachu.png");
	var bulbasor = crearBicho("Bulbasor", "Tierra", 7.5, 8.5, 5, "/img/bulbasor.png");
	var charmander = crearBicho("Charmander", "Agua", 9.3, 6.8, 12, "/img/charmander.png");
	var squirtle = crearBicho("Squirtle", "Aire", 6.5, 8.0, 9, "/img/squirtle.png");
	var chrizard = crearBicho("Chrizard", "Fuego", 8.5, 8.0, 8, "/img/chrizard.png");
	var rattata = crearBicho("Rattata", "Tierra", 7.9, 7.2, 15, "/img/rattata.png");
    
	var pikachu2 = crearBicho("Pikachu 2", "Fuego", 7.5, 8.0, 8, "/img/pikachu2.png");
	var bulbasor2 = crearBicho("Bulbasor 2", "Tierra", 8.5, 8.5, 5, "/img/bulbasor2.png");
	var charmander2 = crearBicho("Charmander 2", "Agua", 9.3, 6.8, 12, "/img/charmander2.png");
	var squirtle2 = crearBicho("Squirtle 2", "Aire", 6.5, 7.9, 9, "/img/squirtle2.png");
	var chrizard2 = crearBicho("Chrizard 2", "Fuego", 8.5, 8.0, 5, "/img/chrizard2.png");
	var rattata2 = crearBicho("Rattata 2", "Tierra", 8.0, 7.2, 15, "/img/rattata2.png");
    
	/*for(var bicho of tablaBichos){    
    	console.log(`_id: ${bicho._id}`);
    	console.log(`Nombre: ${bicho.nombre}`);
    	console.log(`Tipo: ${bicho.tipo}`);
    	console.log(`Fuerza: ${bicho.fuerza}`);
    	console.log(`Velocidad: ${bicho.velocidad}`);
    	console.log(`Edad: ${bicho.edad}`);
    	console.log("......................");
	}*/
    
	var ash = crearEntrenador("Ash");
	var misty = crearEntrenador("Misty");

	/*for(var entr of tablaEntrenadores){
    	console.log(`Id: ${entr._id}`);
    	console.log(`Nombre: ${entr.nombre}`);
    	console.log(`......................`);
	}*/

	crearBichoEntrenador(ash._id, pikachu._id);
	crearBichoEntrenador(ash._id, bulbasor._id);
	crearBichoEntrenador(ash._id, charmander._id);
	crearBichoEntrenador(ash._id, squirtle._id);
	crearBichoEntrenador(ash._id, chrizard._id);
	crearBichoEntrenador(ash._id, rattata._id);

	crearBichoEntrenador(misty._id, pikachu2._id);
	crearBichoEntrenador(misty._id, bulbasor2._id);
	crearBichoEntrenador(misty._id, charmander2._id);
	crearBichoEntrenador(misty._id, squirtle2._id);
	crearBichoEntrenador(misty._id, chrizard2._id);
	crearBichoEntrenador(misty._id, rattata2._id);

	/*for(var bE of tablaBichosEntrenador){
    	console.log(`Id Entrenador: ${bE.idEntrenador}`);
    	console.log(`Id Bicho: ${bE.idBicho}`);
    	console.log(`......................`);
	}*/

}


function MostrarReporte(){
	// Mostrar reporte de las tablas anteriores en una tabla HTML
	var tbody = document.querySelector(".contenedorReporte table tbody");
	
	tbody.innerHTML = "";
	
	for(var bicho of tablaBichos){
		var nuevaFila = `<tr>
					<td>${bicho._id}</td>
					<td>${bicho.nombre}</td>
					<td>${bicho.tipo}</td>
					<td>${bicho.fuerza}</td>
					<td>${bicho.velocidad}</td>
					<td>${bicho.edad}</td>
				</tr>`;
		
		tbody.innerHTML += nuevaFila;
	}
}


window.onload = function(){
	cargarConfiguracion();
};








