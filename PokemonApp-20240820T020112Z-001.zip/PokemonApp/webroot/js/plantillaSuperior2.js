

var plantillaSuperior = `<!doctype html>
<html>
    <head>        
        <title>Mi Plantilla - Perfil</title>
        <link rel="stylesheet" href="/css/styleplantillas.css">
    </head>


    <body>
        <section class="encabezado">
            <i>Pokémon</i>
        </section>`;

        document.write(plantillaSuperior);