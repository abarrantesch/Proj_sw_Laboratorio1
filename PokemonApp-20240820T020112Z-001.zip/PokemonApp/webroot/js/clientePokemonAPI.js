
var mostrandoAlertReto = false;
var mostrandoAlertJuego = false;
var jugando = false;

async function cargarRivales(){

	var inputUsername = document.querySelector("#username");
	var inputMiEquipo = document.querySelector("#miEquipo");
	
	var urlApi = "/pokemonapi/listarrivales?idUsuario=" + inputUsername.value;

	var respuestaServidor = await fetch(urlApi);	
	var rivales = await respuestaServidor.json();
	
	var contenedorRivales = document.querySelector(".contenedorRivales");
	contenedorRivales.innerHTML = "";
	
	let retoQueAceptar = false;
	let retoQueJugar = false;
	let juegoQueMostrar = false;
	
	for(var rival of rivales){
		let nuevoArticle = `<article>
			<h3>${rival.username}</h3>`;
			
		if(rival.accion == "rival"){
		    if(rival.estado == "Jug"){
				nuevoArticle += `<i>Duelo en progreso ...</i><br>`;
			}
			else{
				nuevoArticle += `<i>Esperando respuesta ...</i><br>`;
			}
			
			nuevoArticle += `<form id="${rival.idDuelo}" style="display: none;">
				<input name="idDuelo" value="${rival.idDuelo}"><br>
				<input name="nuevoEstado" value="${rival.estado}"><br>
				<input name="idGanador" value="${rival.idGanador}"><br>
				<input name="equipoRetador" value="${inputMiEquipo.value}"><br>
				<input name="equipoRival" value="${rival.equipoOponente}" placeholder="equipoRival"><br>
			</form>`;
			
			if(rival.estado == "Ace" && retoQueAceptar == false){
				retoQueAceptar = {
					idDuelo: rival.idDuelo,
					username: rival.username,
					miEquipo: rival.miEquipo,
					equipoOponente: rival.equipoOponente
				};
			}
			else if(rival.estado == "Jug" && juegoQueMostrar == false){
				juegoQueMostrar = {
					idDuelo: rival.idDuelo,
					username: rival.username,
					miEquipo: rival.miEquipo,
					equipoOponente: rival.equipoOponente
				};
			}
		}
		else if(rival.accion == "retador"){
		    if(rival.estado == "Inv"){
				nuevoArticle += `<button onclick="AceptarDuelo('${rival.idDuelo}')">Aceptar Duelo</button><br>`;
				nuevoArticle += `<button onclick="RechazarDuelo('${rival.idDuelo}')">Rechazar Duelo</button>`;
			}
			else if(rival.estado == "Ace"){
				nuevoArticle += `<i>Esperando respuesta ...</i><br>`;
			}
		    else if(rival.estado == "Jug"){
				nuevoArticle += `<i>Duelo en progreso ...</i><br>`;
			}
			
			nuevoArticle += `<form id="${rival.idDuelo}" style="display: none;">
				<input name="idDuelo" value="${rival.idDuelo}"><br>
				<input name="nuevoEstado" value="${rival.estado}"><br>
				<input name="idGanador" value="${rival.idGanador}"><br>
				<input name="equipoRetador" value="${rival.equipoOponente}" placeholder="equipoRetador"><br>
				<input name="equipoRival" value="${inputMiEquipo.value}"><br>
			</form>`;
			
			if(rival.estado == "Esp" && retoQueJugar == false){
				retoQueJugar = {
					idDuelo: rival.idDuelo,
					username: rival.username,
				};
			}
			else if(rival.estado == "Jug" && juegoQueMostrar == false){
				juegoQueMostrar = {
					idDuelo: rival.idDuelo,
					username: rival.username,
					/*equipoRetador: rival.equipoRetador,
					equipoRival: rival.equipoRival*/
					miEquipo: rival.miEquipo,
					equipoOponente: rival.equipoOponente
				};
			}
		}
		else{
			nuevoArticle += `<button onclick="InvitarDuelo('${rival.username}')">Invitar Duelo</button>`;
			
			nuevoArticle += `<form id="${rival.username}" style="display: none;">
				<input name="idRetador" value="${inputUsername.value}">
				<input name="idRival" value="${rival.username}">
			</form>`;
		}
		
		nuevoArticle += `</article>`;
		
		
		contenedorRivales.innerHTML += nuevoArticle;
	}
	
	//console.log(`retoQueAceptar: ${retoQueAceptar}, mostrandoAlertReto: ${mostrandoAlertReto}`);
	if(retoQueAceptar != false && mostrandoAlertReto == false){
		Swal.fire({
		  title: `<strong>Reto ${retoQueAceptar.idDuelo}</strong>`,
		  icon: "info",
		  html: `<strong>${retoQueAceptar.username} quiere jugar</strong>`,
		  showCloseButton: true,
		  showCancelButton: true,
		  focusConfirm: false,
		  confirmButtonText: `
			<i class="fa fa-thumbs-up" 
			onclick="EsperarDuelo('${retoQueAceptar.idDuelo}')">Aceptar!</i>
		  `,
		  cancelButtonText: `
			<i class="fa fa-thumbs-down" 
			onclick="CancelarDuelo('${retoQueAceptar.idDuelo}')">Cancelar</i>
		  `
		});
		mostrandoAlertReto = true;
	}
	
	//console.log(`retoQueJugar: ${retoQueJugar}, mostrandoAlertJuego: ${mostrandoAlertJuego}`);
	if(retoQueJugar != false && mostrandoAlertJuego == false){
		Swal.fire({
		  title: `<strong>Reto ${retoQueJugar.idDuelo}</strong>`,
		  icon: "info",
		  html: `<strong>${retoQueJugar.username} está esperandote</strong>`,
		  showCloseButton: true,
		  showCancelButton: true,
		  focusConfirm: false,
		  confirmButtonText: `
			<i class="fa fa-thumbs-up" 
			onclick="JugarDuelo('${retoQueJugar.idDuelo}')">Jugar!</i>
		  `,
		  cancelButtonText: `
			<i class="fa fa-thumbs-down" 
			onclick="CancelarDuelo('${retoQueJugar.idDuelo}')">Cancelar</i>
		  `
		});
		mostrandoAlertJuego = true;
	}
	
	if(juegoQueMostrar != false && jugando == false){
		MostrarDuelo(juegoQueMostrar);
		jugando = true;
	}
}


async function InvitarDuelo(username){
	var formulario = document.querySelector(`#${username}`);
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/insertarduelo", 
									{method: "post", body: datosFormulario});
	var resultado = await respuestaServidor.text();
	
	if(resultado == "true"){
		// mandar correo ..
	}
}


async function AceptarDuelo(idDuelo){
	var formulario = document.querySelector(`#${idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	inputEstado.value = "Ace";
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
	console.log(await respuestaServidor.text());
}


async function RechazarDuelo(idDuelo){
	var formulario = document.querySelector(`#${idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	inputEstado.value = "Rec";
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
	console.log(await respuestaServidor.text());
}


async function EsperarDuelo(idDuelo){
	var formulario = document.querySelector(`#${idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	inputEstado.value = "Esp";
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
	//console.log(await respuestaServidor.text());	
}

async function JugarDuelo(idDuelo){
	var formulario = document.querySelector(`#${idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	inputEstado.value = "Jug";
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
	console.log(await respuestaServidor.text());	
}


async function CancelarDuelo(idDuelo){
	var formulario = document.querySelector(`#${idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	inputEstado.value = "Can";
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
	console.log(await respuestaServidor.text());
}


var dueloTimeout = null;

async function MostrarDuelo(duelo){
	console.log(duelo);//idDuelo: "D-231", username: "misty"

	var inputUsername = document.querySelector("#username");
	
	var nombreUsuarioMio = inputUsername.value;
	var nombreUsuarioOponente = duelo.username;
	
	var misPokemones = await CargarPokemones(nombreUsuarioMio, duelo.miEquipo);
	var pokemonesOponente = await CargarPokemones(nombreUsuarioOponente, duelo.equipoOponente);
	
	if(misPokemones.length == 0 || pokemonesOponente.length == 0){
		var formulario = document.querySelector(`#${duelo.idDuelo}`);
		var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
		inputEstado.value = "Can"; // cancelar
		var datosFormulario = new FormData(formulario);
		respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
		Swal.fire({
			title: "Duelo cancelado!",
			text: "Se ha cancelado el duelo porque tu oponente no tiene pokemones",
			icon: "error"
		});
		
		return false;
	}

	/* Mostrar los pokemones en su respectiva sección */
	var sectionA = document.querySelector("section.A div");
	var sectionB = document.querySelector("section.B div");
	
	sectionA.innerHTML = "";	
	for(var pokemon of misPokemones){
	
		var info = `<article>
			<div>
				Id: <span name="_id">${pokemon._id}</span><br>
				Nombre: <span name="nombre">${pokemon.nombre}</span><br>
				Fuerza: <span name="fuerza">${pokemon.fuerza}</span><br>
				Velocidad: <span name="velocidad">${pokemon.velocidad}</span><br>
				Edad: <span name="edad">${pokemon.edad}</span><br>
			</div>
		    <div>
			 <img src="${pokemon.imagen}">
			</div>
		</article>
		<hr>`;
	
		sectionA.innerHTML += info;
	}
	
	sectionB.innerHTML = "";
	for(var pokemon of pokemonesOponente){
	
		var info = `<article>
		    <div>
			 <img src="${pokemon.imagen}">
			</div>
			<div>
				Id: <span name="_id">${pokemon._id}</span><br>
				Nombre: <span name="nombre">${pokemon.nombre}</span><br>
				Fuerza: <span name="fuerza">${pokemon.fuerza}</span><br>
				Velocidad: <span name="velocidad">${pokemon.velocidad}</span><br>
				Edad: <span name="edad">${pokemon.edad}</span><br>
			</div>
		</article>
		<hr>`;
	
		sectionB.innerHTML += info;
	
	}
	
	var sectionATitulo = document.querySelector("section.A h3");
	var sectionBTitulo = document.querySelector("section.B h3");
	sectionATitulo.innerHTML = nombreUsuarioMio;
	sectionBTitulo.innerHTML = nombreUsuarioOponente;
	
	dueloTimeout = {
		idDuelo: duelo.idDuelo,
		misPokemones: misPokemones,
		pokemonesOponente: pokemonesOponente
	};
	setTimeout(function(){
		EvaluarGane();
	}, 5000);
}


async function EvaluarGane(){
console.log(dueloTimeout);
	/*  HAGA AQUÍ LA VALIDACIÓN DEL ENFRENTAMIENTO DE POKEMONES ...
	DE MOMENTO, ESTÁ AL AZAR, SIN COMPARAR NADA */
	var resultado = "";
	var desempate = Math.floor(Math.random() * 2) + 1;
	var entrenadorGanador = null;
	if(desempate == 1){
		entrenadorGanador = dueloTimeout.misPokemones[0].entrenador;
	}
	else{
		entrenadorGanador = dueloTimeout.pokemonesOponente[0].entrenador;
	}
	resultado += `<div>Este duelo lo gana el entrenador <strong><u>${entrenadorGanador}</u></strong></div>`;
	
	Swal.fire({
		title: "Resultados del duelo",
		html: resultado,
		icon: "info"
	});
	
	var formulario = document.querySelector(`#${dueloTimeout.idDuelo}`);
	var inputEstado = formulario.querySelector("input[name='nuevoEstado']");
	var inputGanador = formulario.querySelector("input[name='idGanador']");
	inputEstado.value = "Fin";
	inputGanador.value = entrenadorGanador;
	var datosFormulario = new FormData(formulario);
	var respuestaServidor = await fetch("/pokemonapi/actualizarduelo", 
									{method: "post", body: datosFormulario});
}


async function CargarPokemones(username, equipo){

	var urlApi = `/pokemonapi/listarpokemonesusuarioequipo?idUsuario=${username}&equipo=${equipo}`;

	var respuestaServidor = await fetch(urlApi);	
	var pokemones = await respuestaServidor.json();
	console.log(pokemones)
	return pokemones;
}


async function CargarMisEquipos(){

	var inputUsername = document.querySelector("#username");
	var selectMiEquipo = document.querySelector("#miEquipo");
	
	var urlApi = "/pokemonapi/misequipos?idUsuario=" + inputUsername.value;

	var respuestaServidor = await fetch(urlApi);	
	var misEquipos = await respuestaServidor.json();
	
	selectMiEquipo.innerHTML = "";
	
	for(var equipo of misEquipos){
		let nuevoEquipo = `<option value="${equipo.equipo}">${equipo.equipo}</option>`;		
		selectMiEquipo.innerHTML += nuevoEquipo;
	}
}


async function SalirIncognito(){
	var inputUsername = document.querySelector("#username");
	
	var respuestaServidor = await fetch("/pokemonapi/eliminarincognito?idUsuario=" + inputUsername.value);
	//var respuesta = await respuestaServidor.json();
	
	location.href = "/registro/login.html";
}

window.onload = async function(){

	var usuarioStr = sessionStorage.getItem("usuario");
	var usuario = JSON.parse(usuarioStr);
	
	if(usuario != null){
		var inputUsername = document.querySelector("#username");
		inputUsername.value = usuario.username;
		
		// Validar si es incógnito para ocultarle las cosas
		if(usuario.perfil == "Incógnito"){
			var menuLateral = document.querySelector(".menuLateral ul");
			//menuLateral.style.display = "none";
			menuLateral.innerHTML = "";
			menuLateral.innerHTML = `<li>
                    <a href="/configuracion/equipos/listado.html">Configurar Equipos</a>
                </li>`;
			menuLateral.innerHTML += `<li>
                    <a href="#" onclick=" SalirIncognito(); ">Salir</a>
                </li>`;
		}
	}

	await CargarMisEquipos();
	setInterval(async function(){
		await cargarRivales();
	}, 1500);
	
	var camposBatalla = [
		"url(/img/Campo_de_batalla_RFVH_11.png)", 
		"url(/img/Campo_de_batalla_RZE_3.png)", 
		"url(/img/Campo_de_batalla_RZE_9.png)"];
	var campoAleatorio = Math.floor(Math.random() * 2) + 0;
	var contenedorRing = document.querySelector(".contenedorRing");
	contenedorRing.backgroundImage = `${camposBatalla[campoAleatorio]}`;
}





