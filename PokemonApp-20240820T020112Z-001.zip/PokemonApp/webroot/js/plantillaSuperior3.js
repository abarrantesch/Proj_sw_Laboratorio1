var plantillaSuperior = `<!doctype html>
<html>
    <head>
        <title>PokemonApp</title>
		<meta charset="UTF-8">
        <link rel="stylesheet" href="/css/estilo.css">
        <link rel="stylesheet" href="/css/estilopopular.css">
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>


    <body>
        <section class="encabezado">
            <i style="font-weight: bold; color: white;">PokemonApp</i>
        </section>`;


document.write(plantillaSuperior);
