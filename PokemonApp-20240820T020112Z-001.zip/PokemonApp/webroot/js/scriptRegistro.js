const container = document.querySelector(".container");
const btnSignIn = document.getElementById("btn-sign-in");
const btnSignUp = document.getElementById("btn-sign-up");

btnSignIn.addEventListener("click",()=>{
   container.classList.remove("toggle");
});
btnSignUp.addEventListener("click",()=>{
   container.classList.add("toggle");
});


function ValidarFormulario( ){

	event.preventDefault( );

	var formularioRegistro = document.querySelector(".container .container-form#formulario2");
	
   
	var inputNombre = formularioRegistro.querySelector("input[name='nombre']");
	var inputApellidos = formularioRegistro.querySelector("input[name='apellidos']");
	var spanValidarNombre = formularioRegistro.querySelector("section.nombre span.validar");
	
	var inputUsuario = formularioRegistro.querySelector("input[name='usuario']");
	var spanValidarUsuario = formularioRegistro.querySelector("section.usuario span.validar");
	
   var inputCorreo = formularioRegistro.querySelector("input[name='email']");
	var spanValidarCorreo = formularioRegistro.querySelector("section.correo span.validar");

   var inputPassword = formularioRegistro.querySelector("input[name='password']");
	var spanValidarPassword = formularioRegistro.querySelector("section.password span.validar");
	
	
	spanValidarNombre.style.display = "none";
	spanValidarUsuario.style.display = "none";
   spanValidarCorreo.style.display = "none";
   spanValidarPassword.style.display = "none";
	
	
	if( inputNombre.value == "" || inputApellidos.value == ""   ){
		spanValidarNombre.style.display = "block";
		return false;
	}

   if( inputUsuario.value == ""){
		spanValidarUsuario.style.display = "block";
		return false;
	}
	
	if( inputCorreo.value == "" || inputCorreo.value.includes("@") == false ){
		spanValidarCorreo.style.display = "block";
		return false;
	}
	
	if( inputPassword.value == ""){
		spanValidarPassword.style.display = "block";
		return false;
	}	
	
	
	Swal.fire({
		html: `<h1>Se ha registrado exitósamente</h1>		
		<br>
		<a href="/index.html">Ir a Página Principal</a>
		`,
	});

	// nos pasamos a la página destino
	//location.href = "index02.html"; CONSULTAR AL PROFE POR LA UBICACIÓN CORRECTA
	return true;	
	
}



/* Función "principal" (main) ... */
window.onload = function(){
	// ...
  
   ValidarFormulario();
   
   
}