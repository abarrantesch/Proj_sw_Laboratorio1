var plantillaSuperior = `<!doctype html>
<html>
    <head>
        <title>PokemonApp</title>
		<meta charset="UTF-8">
        <link rel="stylesheet" href="/css/estilo.css">
        <link rel="stylesheet" href="/css/estilopopular.css">
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>


    <body>
        <section class="encabezado">
            <i style="font-weight: bold; color: white;">PokemonApp</i>
        </section>
        <section class="menuLateral">
            <ul>
                <li><a href="/duelos/">Batallar</a></li>

                <li><a href="/landingpage/Perfil.html">Iniciar Sesión</a></li>

                <li><a href="/landingpage/pantalla_equipos.html">Equipos</a></li>
                
                <li><a href="/landingpage/Social.html">Social</a></li>

                <li><a href="/landingpage/verPerfil.html">Ver Perfiles</a></li>
				
				<hr>
				
            </ul>
           
        </section>`;


document.write(plantillaSuperior);
