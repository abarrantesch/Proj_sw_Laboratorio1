
function MostrarDetalle(idObjeto){
	var columnaOculta = document.querySelector( `#${idObjeto}` );
	var pokemonString = columnaOculta.innerHTML;
	sessionStorage.setItem("pokemonActual", pokemonString);
	location.href = "/configuracion/pokemones/detalle.html";
}

function MostrarNuevo(){
	sessionStorage.removeItem("pokemonActual");
	location.href = "/configuracion/pokemones/detalle.html";
}

async function CargarTabla(){

	var inputUsername = document.querySelector("#username");

	var respuestaServidor = await fetch("/pokemonapi/misequipos?idUsuario=" + inputUsername.value);
	var equipos = await respuestaServidor.json();
	console.log(equipos);

	var contenidoTabla = document.querySelector("table tbody");
	
	contenidoTabla.innerHTML = "";
	
	//{ equipo: "ash-1", pokemones: [ ... ] }
	
	for(var e of equipos){
		for(var p of e.pokemones){
			var objetoString = JSON.stringify(p);
			var nuevaFila = `<tr>
				<td>${p._id}</td>
				<td>${p.nombre}</td>
				<td>${e.equipo}</td>
				<td id="${p._id}" style="display: none;">${objetoString}</td>
				<td>
					<i class="fa-solid fa-trash" 
					  onclick=" EliminarPokemonUsuario('${p._id}', '${inputUsername.value}', '${e.equipo}'); "></i>
				</td>
			</tr>`;		
			contenidoTabla.innerHTML += nuevaFila;
		}
		
		contenidoTabla.innerHTML += `<tr style="background: var(--moradoPopular3);"><td colspan="4"></td></tr>`;
	}
}


async function CargarPokemones(){

	var respuestaServidor = await fetch("/pokemonapi/listarpokemones");
	var pokemones = await respuestaServidor.json();

	var contenidoPokemones = document.querySelector(".contenedorPokemones");
	
	contenidoPokemones.innerHTML = "";
	
	for(var p of pokemones){
		var objetoString = JSON.stringify(p);
		
		var nuevoArticle = `<article onclick=" MostrarParaAgregar('${p._id}', '${p.imagen}'); " style="width: 100px; height: 100px;">
			<img src="${p.imagen}" style="width: 90%; height: 90%;">
			<label>${p.nombre}</label>
		</article>
		
		<hr>`;
		
		
		
		/*var nuevaFila = `<tr>
			<td>${p._id}</td>
			<td>${p.nombre}</td>
			<td>${e.equipo}</td>
			<td id="${p._id}" style="display: none;">${objetoString}</td>
			<td> <i class="fa-solid fa-trash" onclick=" EliminarPokemonEquipo('${p._id}'); "></i> </td>
			
		</tr>`;*/
		
	
		contenidoPokemones.innerHTML += nuevoArticle;
	}
}

function MostrarParaAgregar(idPokemon, imagen){
	var inputIdPokemon = document.querySelector(".contenedorFormulario form input[name='idPokemon']");
	var imgImagen = document.querySelector(".contenedorFormulario form img[name='imagen']");
	
	inputIdPokemon.value = idPokemon;
	imgImagen.src = imagen;
}



async function ValidarFormulario(){

	event.preventDefault();

	var formulario = document.querySelector(".contenedorFormulario form");

	var inputIdPokemon = formulario.querySelector("input[name='idPokemon']");
	var inputEquipo = formulario.querySelector("input[name='equipo']");

	var spanEquipo = formulario.querySelector("span[id='validarEquipo']");
	spanEquipo.style.display = "none";

    var bordeNormal = "1px solid var(--moradoPopular1)";
	inputEquipo.style.borderBottom = bordeNormal;

	var resultadoValidacion = true;

	/* validar nombre no vacío */
	var textoEquipo = inputEquipo.value;
	if(textoEquipo.trim() == ""){
		spanEquipo.style.display = "block";
		inputEquipo.style.borderBottom = "2px solid red";
		//return false;
		resultadoValidacion = false;
	}
	
	if(resultadoValidacion == false) return;
	
	
	var datosFormulario = new FormData(formulario);// multipart
	
	var inputUsername = document.querySelector("#username");
	datosFormulario.append("idUsuario", inputUsername.value);
	
	var url = "/pokemonapi/insertarpokemonusuario";
	
	var respuestaServidor = await fetch(url, 
										{method: "post", body: datosFormulario});
	var respuesta = await respuestaServidor.json();
	
	/*Swal.fire({
		title: "Pokemones",
		text: respuesta.message,
		icon: "success"
	});*/
	
	
	CargarTabla();
}


async function EliminarPokemonUsuario(idPokemon, idUsuario, equipo){
	var datosFormulario = new FormData();
	datosFormulario.append("idPokemon", idPokemon);
	datosFormulario.append("idUsuario", idUsuario);
	datosFormulario.append("equipo", equipo);
	
	var url = "/pokemonapi/eliminarpokemonusuario";
	
	var respuestaServidor = await fetch(url, 
										{method: "post", body: datosFormulario});
	var respuesta = await respuestaServidor.json();
	
	/*Swal.fire({
		title: "Pokemones",
		text: respuesta.message,
		icon: "success"
	});*/
	
	
	CargarTabla();
}

async function SalirIncognito(){
	var inputUsername = document.querySelector("#username");
	
	var respuestaServidor = await fetch("/pokemonapi/eliminarincognito?idUsuario=" + inputUsername.value);
	var respuesta = await respuestaServidor.json();
	
	location.href = "/registro/login.html";
}

window.onload = function(){

	var usuarioStr = sessionStorage.getItem("usuario");
	var usuario = JSON.parse(usuarioStr);
	
	if(usuario != null){
		var inputUsername = document.querySelector("#username");
		inputUsername.value = usuario.username;
		
		
		// Validar si es incógnito para ocultarle las cosas
		if(usuario.perfil == "Incógnito"){
			var menuLateral = document.querySelector(".menuLateral ul");
			//menuLateral.style.display = "none";
			menuLateral.innerHTML = "";
			menuLateral.innerHTML = `<li>
                    <a href="/duelos/">Duelo</a>
                </li>`;
			menuLateral.innerHTML += `<li>
                    <a href="#" onclick=" SalirIncognito(); ">Salir</a>
                </li>`;
		}
	}

	var paginaActual = document.querySelector("#scriptActual").getAttribute("paginaActual");

	if(paginaActual == "listado"){
		CargarTabla();
		
		CargarPokemones();
	}
}




