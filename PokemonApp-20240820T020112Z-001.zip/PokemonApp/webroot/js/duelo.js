var tablaBichos = [];
var tablaEntrenadores = [];
var tablaBichosEntrenador = [];
var tablaDuelos = [];

// CRUD: Create, Read, Update, Delete
function crearBicho(nom, tip, fuer, veloc, eda, ima){
	var nuevoBicho = {
		_id: "Bicho-" + Math.floor(Math.random() * 1000),
		nombre: nom,
		tipo: tip, /* Fuego|Agua|Aire|Tierra */
		fuerza: fuer,
		velocidad: veloc,
		edad: eda,
		imagen: ima
	};
	tablaBichos.push( nuevoBicho );

	return nuevoBicho;
}

function crearEntrenador(nom){
	var nuevoEntrenador = {
		_id: "Entrenador-" + Math.floor(Math.random() * 1000),
		nombre: nom
	};
	tablaEntrenadores.push( nuevoEntrenador );

	return nuevoEntrenador;
}

function crearBichoEntrenador(idEntr, idBic){
	var nuevoBichoEntrenador = {
		idEntrenador: idEntr,
		idBicho: idBic
	};
	tablaBichosEntrenador.push( nuevoBichoEntrenador );
}

function crearDuelo(idBic1, idBic2, gan){
	var nuevoDuelo = {
		idBicho1: idBic1,
		idBicho2: idBic2,
		ganador: gan  /* si gan=0 empate, gan=1 idBicho1, sino idBicho2 */
	};
	tablaDuelos.push( nuevoDuelo );
}

function cargarConfiguracion(){
	/* Cargar algunos bichos */
	var pikachu = crearBicho("Pikachu", "Fuego", 8.5, 8.0, 5, "/img/pikachu.png");
	var bulbasor = crearBicho("Bulbasor", "Tierra", 7.5, 8.5, 5, "/img/bulbasor.png");
	var charmander = crearBicho("Charmander", "Agua", 9.3, 6.8, 12, "/img/charmander.png");
	var squirtle = crearBicho("Squirtle", "Aire", 6.5, 8.0, 9, "/img/squirtle.png");
	var chrizard = crearBicho("Chrizard", "Fuego", 8.5, 8.0, 8, "/img/chrizard.png");
	var rattata = crearBicho("Rattata", "Tierra", 7.9, 7.2, 15, "/img/rattata.png");
	
	var pikachu2 = crearBicho("Pikachu 2", "Fuego", 7.5, 8.0, 8, "/img/pikachu2.png");
	var bulbasor2 = crearBicho("Bulbasor 2", "Tierra", 8.5, 8.5, 5, "/img/bulbasor2.png");
	var charmander2 = crearBicho("Charmander 2", "Agua", 9.3, 6.8, 12, "/img/charmander2.png");
	var squirtle2 = crearBicho("Squirtle 2", "Aire", 6.5, 7.9, 9, "/img/squirtle2.png");
	var chrizard2 = crearBicho("Chrizard 2", "Fuego", 8.5, 8.0, 5, "/img/chrizard2.png");
	var rattata2 = crearBicho("Rattata 2", "Tierra", 8.0, 7.2, 15, "/img/rattata2.png");
	
	/*for(var bicho of tablaBichos){	
		console.log(`_id: ${bicho._id}`);
		console.log(`Nombre: ${bicho.nombre}`);
		console.log(`Tipo: ${bicho.tipo}`);
		console.log(`Fuerza: ${bicho.fuerza}`);
		console.log(`Velocidad: ${bicho.velocidad}`);
		console.log(`Edad: ${bicho.edad}`);
		console.log("......................");
	}*/
	
	var ash = crearEntrenador("Ash");
	var misty = crearEntrenador("Misty");

	/*for(var entr of tablaEntrenadores){
		console.log(`Id: ${entr._id}`);
		console.log(`Nombre: ${entr.nombre}`);
		console.log(`......................`);
	}*/

	crearBichoEntrenador(ash._id, pikachu._id);
	crearBichoEntrenador(ash._id, bulbasor._id);
	crearBichoEntrenador(ash._id, charmander._id);
	crearBichoEntrenador(ash._id, squirtle._id);
	crearBichoEntrenador(ash._id, chrizard._id);
	crearBichoEntrenador(ash._id, rattata._id);

	crearBichoEntrenador(misty._id, pikachu2._id);
	crearBichoEntrenador(misty._id, bulbasor2._id);
	crearBichoEntrenador(misty._id, charmander2._id);
	crearBichoEntrenador(misty._id, squirtle2._id);
	crearBichoEntrenador(misty._id, chrizard2._id);
	crearBichoEntrenador(misty._id, rattata2._id);

	/*for(var bE of tablaBichosEntrenador){
		console.log(`Id Entrenador: ${bE.idEntrenador}`);
		console.log(`Id Bicho: ${bE.idBicho}`);
		console.log(`......................`);
	}*/

}

function EmpezarDuelo(entrenador1, entrenador2, bichosA, bichosB){	

	/* Hacemos los cálculos para ver quién ganó */
	var cantidadDeDuelos = 6;
	var resultado = "";
	var puntosEntrenador1 = 0;
	var puntosEntrenador2 = 0;	
	
	for(var i = 0; i < cantidadDeDuelos; i++){
		var bicho1 = bichosA[i];
		var bicho2 = bichosB[i];
		
		var puntosBicho1 = 0;
		var puntosBicho2 = 0;
		
		resultado += `<h1>
						<img class="iconoVersus" src="${bicho1.imagen}">
						${bicho1.nombre}
						<i>VS</i>
						${bicho2.nombre}
						<img class="iconoVersus" src="${bicho2.imagen}">
					  </h1>`;
		
		// Comparar fuerza
		if(bicho1.fuerza > bicho2.fuerza){
			puntosBicho1 = puntosBicho1 + 1;
			resultado += `<div>${bicho1.nombre} es más fuerte que ${bicho2.nombre}</div>`;
		}
		else if(bicho1.fuerza < bicho2.fuerza){
			puntosBicho2 += 1;
			resultado += `<div>${bicho2.nombre} es más fuerte que ${bicho1.nombre}</div>`;
		}
		
		// Comparar velocidad
		if(bicho1.velocidad > bicho2.velocidad){
			puntosBicho1 = puntosBicho1 + 1;
			resultado += `<div>${bicho1.nombre} es más veloz que ${bicho2.nombre}</div>`;
		}
		else if(bicho1.velocidad < bicho2.velocidad){
			puntosBicho2 += 1;
			resultado += `<div>${bicho2.nombre} es más veloz que ${bicho1.nombre}</div>`;
		}
		
		// Comparar edad
		if(bicho1.edad > bicho2.edad){
			puntosBicho1 = puntosBicho1 + 1;
			resultado += `<div>${bicho1.nombre} es más experimentado que ${bicho2.nombre}</div>`;
		}
		else if(bicho1.edad < bicho2.edad){
			puntosBicho2 += 1;
			resultado += `<div>${bicho2.nombre} es más experimentado que ${bicho1.nombre}</div>`;
		}		
		
		// Comparar resultado particular y sumar al total por entrenador
		if(puntosBicho1 > puntosBicho2){
			puntosEntrenador1++;
		}
		else if(puntosBicho1 < puntosBicho2){
			puntosEntrenador2++;
		}
		else{ // empate
			var desempate = Math.floor(Math.random() * 2) + 1;
			if(desempate == 1){
				puntosEntrenador1++;
			    resultado += `<div>Quedaron empatados, pero por 'moneda' gana ${bicho1.nombre}</div>`;
			}
			else{
				puntosEntrenador2++;
			    resultado += `<div>Quedaron empatados, pero por 'moneda' gana ${bicho2.nombre}</div>`;
			}
		}
		
		resultado += "<hr>";
		
	} // fin del for
	
	if(puntosEntrenador1 > puntosEntrenador2){
		resultado += `<div>Este duelo lo gana el entrenador ${entrenador1.nombre}</div>`;
	}
	else if(puntosEntrenador1 < puntosEntrenador2){
		resultado += `<div>Este duelo lo gana el entrenador ${entrenador2.nombre}</div>`;
	}
	else{ // empate
		var desempate = Math.floor(Math.random() * 2) + 1;
		if(desempate == 1){
			resultado += `<div>Este duelo lo gana el entrenador <strong><u>${entrenador1.nombre}</u></strong></div>`;
		}
		else{
			resultado += `<div>Este duelo lo gana el entrenador <strong><u>${entrenador2.nombre}</u></strong></div>`;
		}
	}
	
	console.log(resultado);
	
	/* Mostrar los resultados */	
	setTimeout( function(){
		MostrarResultado(resultado);
	}, 100);
}

function MostrarResultado(resultado){
	Swal.fire({
	  title: "<strong>Resultados del duelo</strong>",
	  icon: "info",
	  html: resultado,
	  showCloseButton: true,
	  showCancelButton: true,
	  focusConfirm: false,
	  confirmButtonText: `
		<i class="fa fa-thumbs-up"></i> Great!
	  `,
	  confirmButtonAriaLabel: "Thumbs up, great!"
	});
}


function EmpezarAnimacionDuelo(entrenador1, entrenador2){

	/* Mostrar los bichos en su respectiva sección */
	var sectionA = document.querySelector("section.A div");
	var sectionB = document.querySelector("section.B div");
	
	var ids1 = tablaBichosEntrenador.filter(bE => bE.idEntrenador == entrenador1._id);
	var ids2 = tablaBichosEntrenador.filter(bE => bE.idEntrenador == entrenador2._id);
	
	var bichosA = [];
	var bichosB = [];
	
	for(var item of ids1){
		var idBicho = item.idBicho;
		var bicho = tablaBichos.filter(b => b._id == idBicho)[0];
		bichosA.push(bicho);
	}
	
	for(var item of ids2){
		var idBicho = item.idBicho;
		var bicho = tablaBichos.filter(b => b._id == idBicho)[0];
		bichosB.push(bicho);
	}
	
	sectionA.innerHTML = "";
	
	for(var bicho of bichosA){
	
		var info = `<article style="left: 0; transition: left 1s ease;">
		    <div>
			 <img src="${bicho.imagen}">
			</div>
			<div style="display: none;">
				Id: <input name="_id" value="${bicho._id}"><br>
				Nombre: <input name="nombre" value="${bicho.nombre}" oninput="this.size = this.value.length + 1"><br>
				Fuerza: <input name="fuerza" value="${bicho.fuerza}"><br>
				Velocidad: <input name="velocidad" value="${bicho.velocidad}"><br>
				Edad: <input name="edad" value="${bicho.edad}"><br>
			</div>
		</article>
		<hr>`;
	
		sectionA.innerHTML += info;
	
	}
	
	sectionB.innerHTML = "";
	
	for(var bicho of bichosB){
	
		var info = `<article style="left: 0; transition: left 1s ease;">
		    <div>
			 <img src="${bicho.imagen}">
			</div>
			<div style="display: none">
				Id: <input name="_id" value="${bicho._id}"><br>
				Nombre: <input name="nombre" value="${bicho.nombre}" oninput="this.size = this.value.length + 1"><br>
				Fuerza: <input name="fuerza" value="${bicho.fuerza}"><br>
				Velocidad: <input name="velocidad" value="${bicho.velocidad}"><br>
				Edad: <input name="edad" value="${bicho.edad}"><br>
			</div>
		</article>
		<hr>`;
	
		sectionB.innerHTML += info;
	
	}
	
	var sectionATitulo = document.querySelector("section.A h3");
	var sectionBTitulo = document.querySelector("section.B h3");
	sectionATitulo.innerHTML = entrenador1.nombre;
	sectionBTitulo.innerHTML = entrenador2.nombre;

	/* Tomar los article (bichos) de cada sección */
	var sectionA = document.querySelector("section.A div");
	var sectionB = document.querySelector("section.B div");
	
	var articlesA = sectionA.querySelectorAll("article");
	console.log(articlesA);
	var articlesB = sectionB.querySelectorAll("article");
	
	for(var i = 0; i < 6; i++){	
	    var artA = articlesA[i];
		MoverBicho(sectionA, artA, 1);
		
		var artB = articlesB[i];
		var bichoWidth = artB.offsetWidth;
		var sectionWidth = sectionB.offsetWidth;
		var trasladar = `${sectionWidth - bichoWidth}px`;
		artB.style.transform = `translateX(${trasladar})`;
		MoverBicho(sectionB, artB, -1);		
	}
	
	setTimeout(function(){
		EmpezarDuelo(entrenador1, entrenador2, bichosA, bichosB);
	}, 1000);
}

function MoverBicho(section, bicho, direction){
	var bichoLeft = parseInt( bicho.style.left );
	var bichoWidth = bicho.offsetWidth;
	var sectionWidth = section.offsetWidth;
	
	var limit = (sectionWidth - bichoWidth) * direction;
	
	if(bichoLeft != limit){
		bicho.style.left = `${limit}px`;
	}
}




window.onload = function(){
	cargarConfiguracion();
	
	var btnEmpezarDuelo = document.querySelector(".contenedorRing input[type='button']");
	btnEmpezarDuelo.addEventListener("click", function(){
		
		var e1 = tablaEntrenadores[0];
		var e2 = tablaEntrenadores[1];
				
		//EmpezarDuelo(e1, e2);
		EmpezarAnimacionDuelo(e1, e2);
	});
}





