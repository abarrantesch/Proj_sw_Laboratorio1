
function ValidarFormulario(){

	event.preventDefault();

	var formularioContacto = document.querySelector(".contenedorFormulario form");
	
	//<input type="text" name="nombre" />
	//var inputNombre = document.querySelector(".contenedorFormulario form input[name='nombre']");
	var inputNombre = formularioContacto.querySelector("input[name='nombre']");
	var inputApellidos = formularioContacto.querySelector("input[name='apellidos']");
	var spanValidarNombre = formularioContacto.querySelector("section.nombre span.validar");
	
	var inputCorreo = formularioContacto.querySelector("input[name='correo']");
	var spanValidarCorreo = formularioContacto.querySelector("section.correo span.validar");
	
	var selectPais = formularioContacto.querySelector("select[name='pais']");
	var spanValidarPais = formularioContacto.querySelector("section.pais span.validar");
	
	spanValidarNombre.style.display = "none";
	spanValidarCorreo.style.display = "none";
	spanValidarPais.style.display = "none";
	
	if( inputNombre.value == "" || inputApellidos.value == ""   ){
		spanValidarNombre.style.display = "block";
		return false;
	}
	
	if( inputCorreo.value == "" || inputCorreo.value.includes("@") == false ){
		spanValidarCorreo.style.display = "block";
		return false;
	}
	
	if( selectPais.value == "--Seleccione un país--" ){
		spanValidarPais.style.display = "block";
		return false;
	}
	
	
	
	Swal.fire({
	  title: "Buen trabajo!",
	  text: "Formulario Validado!",
	  icon: "success"
	});
	
	return true;
	
	
}


function CalcularArea( ){

	event.preventDefault();
	
	var inputBase = document.querySelector("section.triangulo input[name='base']");
	var inputAltura = document.querySelector("section.triangulo input[name='altura']");
	var inputArea = document.querySelector("section.triangulo input[name='area']");
	
	var spanValidarBase = document.querySelector("section.triangulo span.validarBase");
	var spanValidarAltura = document.querySelector("section.triangulo span.validarAltura");
	
	spanValidarBase.style.display = "none";
	spanValidarAltura.style.display = "none";
	inputArea.value = "";
	
	if(inputBase.value.trim() == ""){
		spanValidarBase.style.display = "block";
		return;
	}
	
	if(inputAltura.value.trim() == ""){
		spanValidarAltura.innerHTML = "Introduzca un valor para la altura";
		spanValidarAltura.style.display = "block";
		return;
	}
	else{
		var noEsNumerico = isNaN(inputAltura.value); // isNaN: isNotaNumber?
		if(noEsNumerico == true){
			spanValidarAltura.innerHTML = "No se permiten letras en la altura";
			spanValidarAltura.style.display = "block";
			return;
		}
	}
	
	var base = parseInt(  inputBase.value  );
	var altura = parseInt(   inputAltura.value );
	
	var area = (base * altura) / 2;
	
	inputArea.value = area;
	
}


/* Función "principal" (main) ... */
window.onload = function(){
	// ...
}






