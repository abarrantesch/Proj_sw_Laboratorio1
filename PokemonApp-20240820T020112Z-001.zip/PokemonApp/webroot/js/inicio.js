

window.onload = function(){
	// obtener el usuario de la sesión
	var usuarioStr = sessionStorage.getItem("usuario");
	var usuario = JSON.parse(usuarioStr);
	
	if(usuario != null && usuario.perfil != "Incógnito"){
		var spanUsuario = document.querySelector("#usuario");
		spanUsuario.innerHTML = `Bienvenid@ ${usuario.username}!`;
		
		var imgUsuario = document.querySelector(".contenedorHome img");
		imgUsuario.src = usuario.foto;
	}
	else{
		location.href = "/registro/login.html";
	}
};