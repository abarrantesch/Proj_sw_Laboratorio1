

async function EnviarCorreo(){

	 var formulario = document.querySelector(".contenedorFormulario form");
	 var inputDe = formulario.querySelector("input[name='de']");
	 var inputPara = formulario.querySelector("input[name='para']");
	 var textareaMensaje = formulario.querySelector("textarea[name='mensaje']");
	 
	 if(inputDe.value.trim() == "" || inputPara.value.trim() == "" || textareaMensaje.value.trim() == ""){
	  // sweet alert ...
	  return false;
	 }

	 var datosPost = new FormData(formulario);
	 var respuestaServidor = await fetch("/pokemonapi/enviarcorreo", {method: "post", body: datosPost });
	 var textoRespuesta = await respuestaServidor.text();
	 
	 // sweet alert 
	 console.log(textoRespuesta);
	 return true;
}






