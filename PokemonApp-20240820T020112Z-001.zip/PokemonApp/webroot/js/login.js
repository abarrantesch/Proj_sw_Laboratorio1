

/*var tablaUsuarios = [
	{usuario: "aaa", contrasena: "123"},
	{usuario: "bbb", contrasena: "456"},
	{usuario: "ccc", contrasena: "789"}
];*/

async function Login(formulario){

	var inputUsuario = formulario.querySelector("input[name='usuario']");
	var inputContrasena = formulario.querySelector("input[name='contrasena']");
	
	/*var encontrado = false;
	for(var u of tablaUsuarios){
		if(inputUsuario.value.trim() == u.usuario && inputContrasena.value.trim() == u.contrasena){
			// encontró un usuario con la combinación
			// vamos a guardarlo en el sessionStorage, hay que pasar el objeto a string
			var usuarioString = JSON.stringify(u);
			sessionStorage.setItem("UsuarioLogueado", usuarioString);
			
			encontrado = true;
			
			// nos pasamos a la página destino
			location.href = "/index.html";
		}
	}*/
	
	let validar = document.querySelectorAll(".validar");
	for(let span of validar){
		span.innerHTML = "Introduzca un valor para este campo.";
		span.style.display = "none";
	}
	
	var formulario = document.querySelector(".contenedorFormulario form");
	var datosFormulario = new FormData(formulario);
	
	var respuestaServidor = await fetch("/pokemonapi/login", {method: "post", body: datosFormulario} );
		
	var usuario = await respuestaServidor.json();
	console.log(usuario);
	
	if(JSON.stringify(usuario) == "{}" ){
		for(let span of validar){
			span.innerHTML = "Alguno de los datos está incorrecto";
			span.style.display = "block";
		}
	}
	else{
		var usuarioStr = JSON.stringify(usuario);
		sessionStorage.setItem("usuario", usuarioStr);
		
		location.href = "/index.html";
	}
}



function ValidarFormulario(){

	event.preventDefault();

	var formulario = document.querySelector(".contenedorFormulario form");
	var inputUsuario = formulario.querySelector("input[name='usuario']");
	var inputContrasena = formulario.querySelector("input[name='contrasena']");
	
	let validar = document.querySelectorAll(".validar");
	for(let span of validar){
		span.innerHTML = "Introduzca un valor para este campo.";
		span.style.display = "none";
	}
	
	if(inputUsuario.value.trim() == "" && inputContrasena.value.trim() == ""){
		for(let span of validar){
			span.style.display = "block";
		}
		return;
	}
	
	Login(formulario);
	return true;
}


async function IngresarIncognito(){
	// Generar un usuario temporal en la base de datos.
	// Como la tabla de Usuarios tiene un campo "perfil", 
	// entonces usaremos ese para reconocer a los incógnitos.
	// El usuario erá eliminado cuando cierre la sesión del navegador.
	
	var respuestaServidor = await fetch("/pokemonapi/generarincognito");
	var usuario = await respuestaServidor.json();
	
	if(JSON.stringify(usuario) == "{}" ){
		Swal.fire({
			title: "Pokemones",
			text: respuesta.message,
			icon: "error"
		});
	}
	else{
		var usuarioStr = JSON.stringify(usuario);
		sessionStorage.setItem("usuario", usuarioStr);
		
		location.href = "/duelos/index.html";
	}
}



