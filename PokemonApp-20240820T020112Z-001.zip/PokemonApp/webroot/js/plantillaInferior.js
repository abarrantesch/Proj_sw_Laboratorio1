var plantillaInferior = `<section class="piePagina">
	<a href="/landingpage/empresa.html">Net2You</a>	
	<p>Copyright 2024</p>
</section>
</body>
</html>`;


document.write(plantillaInferior);
