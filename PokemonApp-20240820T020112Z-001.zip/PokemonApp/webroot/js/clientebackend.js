
async function Login(){

	event.preventDefault();

	var formulario = document.querySelector(".contenedorFormulario form");
	
	var datosFormulario = new FormData( formulario );
	var respuestaServidor = await fetch("/api/login", {method: "post", body: datosFormulario} );
		
	if(await respuestaServidor.text() == "Error"){
		alert("Error");
	}
	else{
		location.href = "/ejemplobackend/usuarios.html";
	}
}


async function Mostrar(){
	var tbody = document.querySelector(".contenedorTabla tbody");
	var formulario = document.querySelector(".contenedorFormulario form");
	
	if(tbody == undefined){ 
		// si no encontró la tabla, este no es el archivo usuarios.html
		return;
	}
	
	var respuestaServidor = await fetch("/api/obtenerusuario"); // get
	var tablaUsuarios = await respuestaServidor.json();
	
	console.log(tablaUsuarios);
	
	if(tablaUsuarios.length == 1){ // mostrará el formulario
		var inputId = formulario.querySelector("input[name='_id']");
		var inputNombre = formulario.querySelector("input[name='nombre']");
		var inputPais = formulario.querySelector("input[name='pais']");
		
		var usuario = tablaUsuarios[0];
		inputId.value = usuario._id;
		inputNombre.value = usuario.nombre;
		inputPais.value = usuario.pais;
	}
	else{
		tbody.innerHTML = "";
		for(var usuario of tablaUsuarios){
			var fila = `<tr>
				<td>${usuario._id}</td>
				<td>${usuario.nombre}</td>
				<td>${usuario.pais}</td>
			</tr>`;
			tbody.innerHTML += fila;
		}
	}
}


window.onload = async function(){
	await Mostrar();
}
























