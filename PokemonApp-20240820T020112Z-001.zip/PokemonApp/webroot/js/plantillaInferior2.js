
var plantillaInferior = `<section class="piePagina">
<h1>Net2You</h1>	
<p>Copyright 2024</p>
</section>
</body>
</html>`;

document.write(plantillaInferior);